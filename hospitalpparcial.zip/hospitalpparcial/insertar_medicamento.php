<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: index.php");
    exit;
}

require 'db.php';

$mensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['Nombre_Medicamento'];
    $descripcion = $_POST['Descripción_Medicamento'];

    $stmt = $pdo->prepare("CALL insertar_medicamento(?, ?)");
    $stmt->execute([$nombre, $descripcion]);

    $mensaje = " Medicamento registrado exitosamente.";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Insertar Medicamento</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h2>Registrar Medicamento</h2>
    <?php if ($mensaje): ?>
        <div class="alert alert-success"><?= $mensaje ?></div>
    <?php endif; ?>
    <form method="POST">
    <div class="mb-3">
        <label>Nombre del Medicamento:</label>
        <input type="text" name="Nombre_Medicamento" class="form-control" required>
    </div>
    <div class="mb-3">
        <label>Descripción:</label>
        <textarea name="Descripción_Medicamento" class="form-control" required></textarea>
    </div>
    <button class="btn btn-primary">Guardar</button>
</form>

</body>
</html>

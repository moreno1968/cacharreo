<?php
session_start();
require 'db.php';

$mensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $password = $_POST['password'];

  
    if (isset($_POST['registrar'])) {
        $rol = $_POST['rol'];
        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $pdo->prepare("INSERT INTO usuarios (nombre, password_hash, rol) VALUES (?, ?, ?)");
        $stmt->execute([$nombre, $password_hash, $rol]);

        $mensaje = "Usuario registrado correctamente. Ahora puedes iniciar sesión.";
    }

   
    if (isset($_POST['login'])) {
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE nombre = ?");
        $stmt->execute([$nombre]);
        $usuario = $stmt->fetch();

        if ($usuario) {
            
            if ($usuario['bloqueado']) {
                $tiempoBloqueo = strtotime($usuario['ultima_fecha_bloqueo']);
                $ahora = time();
                $diferencia = ($ahora - $tiempoBloqueo) / 60;

                if ($diferencia >= 2) {
                  
                    $stmt = $pdo->prepare("UPDATE usuarios SET bloqueado = 0, intentos_fallidos = 0, ultima_fecha_bloqueo = NULL WHERE id_usuario = ?");
                    $stmt->execute([$usuario['id_usuario']]);
                    $usuario['bloqueado'] = 0;
                    $usuario['intentos_fallidos'] = 0;
                } else {
                    $mensaje = "Usuario bloqueado. Intenta de nuevo en " . ceil(2 - $diferencia) . " minutos.";
                }
            }

            if (!$usuario['bloqueado']) {
                if (password_verify($password, $usuario['password_hash'])) {
                 
                    $stmt = $pdo->prepare("UPDATE usuarios SET intentos_fallidos = 0 WHERE id_usuario = ?");
                    $stmt->execute([$usuario['id_usuario']]);

                    $_SESSION['usuario_id'] = $usuario['id_usuario'];
                    $_SESSION['nombre'] = $usuario['nombre'];
                    $_SESSION['rol'] = $usuario['rol'];

                    header('Location: dashboard.php');
                    exit;
                } else {
                  
                    $intentos = $usuario['intentos_fallidos'] + 1;
                    $bloquear = $intentos >= 3 ? 1 : 0;
                    $fecha_bloqueo = $bloquear ? date('Y-m-d H:i:s') : null;

                    $stmt = $pdo->prepare("UPDATE usuarios SET intentos_fallidos = ?, bloqueado = ?, ultima_fecha_bloqueo = ? WHERE id_usuario = ?");
                    $stmt->execute([$intentos, $bloquear, $fecha_bloqueo, $usuario['id_usuario']]);

                    $mensaje = $bloquear ? "Cuenta bloqueada por 2 minutos." : "Contraseña incorrecta. Intento $intentos de 3.";
                }
            }
        } else {
            $mensaje = "Usuario no encontrado.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login y Registro</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h2 class="mb-4">Autenticación</h2>
    <?php if ($mensaje): ?>
        <div class="alert alert-info"><?= $mensaje ?></div>
    <?php endif; ?>

    <div class="row">
        <!-- Login -->
        <div class="col-md-6">
            <h4>Iniciar Sesión</h4>
            <form method="POST">
                <div class="mb-3">
                    <label>Nombre de usuario:</label>
                    <input type="text" name="nombre" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>Contraseña:</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <button name="login" class="btn btn-primary">Entrar</button>
            </form>
        </div>

        <!-- Registro -->
        <div class="col-md-6">
            <h4>Registrarse</h4>
            <form method="POST">
                <div class="mb-3">
                    <label>Nombre de usuario:</label>
                    <input type="text" name="nombre" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>Contraseña:</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>Rol:</label>
                    <select name="rol" class="form-control" required>
                        <option value="Administrador">Administrador</option>
                        <option value="Medico">Médico</option>
                        <option value="Recepcionista">Recepcionista</option>
                    </select>
                </div>
                <button name="registrar" class="btn btn-success">Registrarse</button>
            </form>
        </div>
    </div>
</body>
</html>

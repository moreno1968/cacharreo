<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h2 class="mb-4">Bienvenido, <?= htmlspecialchars($_SESSION['nombre']) ?> (<?= $_SESSION['rol'] ?>)</h2>

    <div class="mb-3">
        <a href="logout.php" class="btn btn-danger">Cerrar sesión</a>
    </div>

    <div class="row">
        <div class="col-md-4">
            <a href="vista_medicamentos.php" class="btn btn-outline-primary w-100 mb-3">📋 Ver Medicamentos</a>
        </div>
        <div class="col-md-4">
            <a href="insertar_medicamento.php" class="btn btn-outline-success w-100 mb-3">➕ Agregar Medicamento</a>
        </div>
        <div class="col-md-4">
            <a href="vista_sedes.php" class="btn btn-outline-info w-100 mb-3">🏥 Ver Sedes</a>
        </div>
        <!-- Agrega más enlaces aquí según los módulos que desarrolles -->
    </div>
</body>
</html>

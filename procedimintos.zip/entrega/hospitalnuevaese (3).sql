-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 03-03-2025 a las 20:42:31
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `hospitalnuevaese`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenerHorariosPorEspecialidad` (IN `p_Especialidad` VARCHAR(100))   BEGIN
    SELECT h.*, m.Nombre AS Nombre_Medico, m.Apellidos AS Apellido_Medico
    FROM horarios_medicos h
    JOIN medicos m ON h.ID_Medico = m.ID_Medico
    WHERE m.Especialidad = p_Especialidad
    ORDER BY h.Día, h.Hora_Inicio;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenerPacientePorID` (IN `ID_paciente` INT)   BEGIN
    SELECT * FROM pacientes WHERE ID_paciente = ID_paciente;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenerPacientesPorMedicamento` (IN `p_NombreMedicamento` VARCHAR(255))   BEGIN
    SELECT p.ID_Paciente, p.Nombre, p.Apellido, m.Nombre_Medicamento AS Medicamento
    FROM pacientes p
    JOIN formulas_medicas f ON p.ID_Paciente = f.ID_Paciente
    JOIN medicamentos m ON f.ID_Medicamento = m.ID_Medicamento
    WHERE m.Nombre_Medicamento = p_NombreMedicamento;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `citas`
--

CREATE TABLE `citas` (
  `ID_Cita` int(11) NOT NULL,
  `ID_Paciente` int(11) DEFAULT NULL,
  `ID_Medico` int(11) DEFAULT NULL,
  `Fecha_Cita` date DEFAULT NULL,
  `Hora_Cita` time DEFAULT NULL,
  `Motivo_Cita` text DEFAULT NULL,
  `Estado_Cita` enum('Pendiente','Confirmada','Cancelada') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `citas`
--

INSERT INTO `citas` (`ID_Cita`, `ID_Paciente`, `ID_Medico`, `Fecha_Cita`, `Hora_Cita`, `Motivo_Cita`, `Estado_Cita`) VALUES
(1, 11, 5, '2025-03-10', '08:30:00', 'Chequeo general', 'Pendiente'),
(3, 13, 15, '2025-03-12', '09:45:00', 'Dolor de articulaciones', 'Pendiente'),
(4, 14, 7, '2025-03-13', '14:00:00', 'Traumatismo en la pierna', 'Cancelada'),
(5, 15, 3, '2025-03-14', '11:30:00', 'Revisión pediátrica', 'Pendiente'),
(6, 16, 20, '2025-03-15', '16:00:00', 'Consulta preoperatoria', 'Confirmada'),
(7, 17, 9, '2025-03-16', '13:15:00', 'Consulta psiquiátrica', 'Pendiente'),
(8, 18, 12, '2025-03-17', '09:00:00', 'Chequeo endocrino', 'Confirmada'),
(9, 19, 2, '2025-03-18', '12:00:00', 'Evaluación neurológica', 'Pendiente'),
(10, 20, 8, '2025-03-19', '17:30:00', 'Revisión oncológica', 'Cancelada'),
(11, 21, 14, '2025-03-20', '08:00:00', 'Consulta neumológica', 'Pendiente'),
(12, 22, 18, '2025-03-21', '15:45:00', 'Chequeo post-quirúrgico', 'Confirmada'),
(13, 23, 6, '2025-03-22', '10:30:00', 'Revisión oftalmológica', 'Pendiente'),
(14, 24, 11, '2025-03-23', '11:00:00', 'Consulta gastroenterológica', 'Confirmada'),
(15, 25, 1, '2025-03-24', '14:30:00', 'Chequeo cardiológico', 'Pendiente'),
(16, 26, 4, '2025-03-25', '16:15:00', 'Consulta dermatológica', 'Cancelada'),
(17, 27, 17, '2025-03-26', '09:20:00', 'Consulta otorrinolaringológica', 'Pendiente'),
(18, 28, 22, '2025-03-27', '13:40:00', 'Evaluación geriátrica', 'Confirmada'),
(19, 29, 25, '2025-03-28', '12:10:00', 'Consulta médica general', 'Pendiente'),
(20, 30, 16, '2025-03-29', '15:00:00', 'Revisión hematológica', 'Pendiente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `facturacion`
--

CREATE TABLE `facturacion` (
  `ID_Factura` int(11) NOT NULL,
  `ID_Paciente` int(11) DEFAULT NULL,
  `ID_Medico` int(11) DEFAULT NULL,
  `ID_Cita` int(11) DEFAULT NULL,
  `Fecha_Factura` date DEFAULT NULL,
  `pago_Total` decimal(10,2) DEFAULT NULL,
  `Descripción` text DEFAULT NULL,
  `Metodo_Pago` enum('Efectivo','Tarjeta','Transferencia') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `facturacion`
--

INSERT INTO `facturacion` (`ID_Factura`, `ID_Paciente`, `ID_Medico`, `ID_Cita`, `Fecha_Factura`, `pago_Total`, `Descripción`, `Metodo_Pago`) VALUES
(1, 11, 5, 1, '2025-03-10', 120000.00, 'Pago por chequeo general', ''),
(3, 13, 15, 3, '2025-03-12', 180000.00, 'Pago por consulta de dolor de articulaciones', ''),
(4, 14, 7, 4, '2025-03-13', 100000.00, 'Pago por consulta de traumatismo en la pierna', ''),
(5, 15, 3, 5, '2025-03-14', 130000.00, 'Pago por revisión pediátrica', 'Efectivo'),
(6, 16, 20, 6, '2025-03-15', 200000.00, 'Pago por consulta preoperatoria', ''),
(7, 17, 9, 7, '2025-03-16', 170000.00, 'Pago por consulta psiquiátrica', ''),
(8, 18, 12, 8, '2025-03-17', 140000.00, 'Pago por chequeo endocrino', 'Efectivo'),
(9, 19, 2, 9, '2025-03-18', 190000.00, 'Pago por evaluación neurológica', ''),
(10, 20, 8, 10, '2025-03-19', 160000.00, 'Pago por revisión oncológica', ''),
(11, 21, 14, 11, '2025-03-20', 130000.00, 'Pago por consulta neumológica', 'Efectivo'),
(12, 22, 18, 12, '2025-03-21', 210000.00, 'Pago por chequeo post-quirúrgico', ''),
(13, 23, 6, 13, '2025-03-22', 125000.00, 'Pago por revisión oftalmológica', ''),
(14, 24, 11, 14, '2025-03-23', 175000.00, 'Pago por consulta gastroenterológica', ''),
(15, 25, 1, 15, '2025-03-24', 160000.00, 'Pago por chequeo cardiológico', 'Efectivo'),
(16, 26, 4, 16, '2025-03-25', 110000.00, 'Pago por consulta dermatológica', ''),
(17, 27, 17, 17, '2025-03-26', 135000.00, 'Pago por consulta otorrinolaringológica', 'Efectivo'),
(18, 28, 22, 18, '2025-03-27', 220000.00, 'Pago por evaluación geriátrica', ''),
(19, 29, 25, 19, '2025-03-28', 145000.00, 'Pago por consulta médica general', ''),
(20, 30, 16, 20, '2025-03-29', 155000.00, 'Pago por revisión hematológica', 'Efectivo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `formulas_medicas`
--

CREATE TABLE `formulas_medicas` (
  `ID_Formula` int(11) NOT NULL,
  `ID_Paciente` int(11) DEFAULT NULL,
  `ID_Medico` int(11) DEFAULT NULL,
  `Fecha_Formula` date DEFAULT NULL,
  `Indicaciones` text DEFAULT NULL,
  `ID_Medicamento` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `formulas_medicas`
--

INSERT INTO `formulas_medicas` (`ID_Formula`, `ID_Paciente`, `ID_Medico`, `Fecha_Formula`, `Indicaciones`, `ID_Medicamento`) VALUES
(1, 11, 1, '2025-02-25', 'Tomar con agua después de las comidas', 1),
(2, 12, 2, '2025-02-24', 'No exceder la dosis recomendada', 2),
(3, 13, 3, '2025-02-23', 'Tomar con alimentos para evitar irritación gástrica', 3),
(4, 14, 4, '2025-02-22', 'Tomar en ayunas con un vaso de agua', 4),
(5, 15, 5, '2025-02-21', 'No combinar con alcohol', 5),
(6, 16, 6, '2025-02-20', 'Tomar con abundante agua', 6),
(7, 17, 7, '2025-02-19', 'Tomar antes de dormir', 7),
(8, 18, 8, '2025-02-18', 'Usar solo en caso de crisis asmática', 8),
(9, 19, 9, '2025-02-17', 'Completar el tratamiento de 7 días', 9),
(10, 20, 10, '2025-02-16', 'No tomar en ayunas', 10),
(11, 11, 11, '2025-02-15', 'Evitar actividades que requieran atención', 11),
(12, 12, 12, '2025-02-14', 'Tomar solo cuando sea necesario', 12),
(13, 13, 13, '2025-02-13', 'No exceder la dosis diaria', 13),
(14, 14, 14, '2025-02-12', 'Tomar con el desayuno', 14),
(15, 15, 15, '2025-02-11', 'No combinar con otros inhibidores gástricos', 15),
(16, 16, 16, '2025-02-10', 'Seguir las indicaciones del médico', 16),
(17, 17, 17, '2025-02-09', 'Evitar el consumo de sal', 17),
(18, 18, 18, '2025-02-08', 'Tomar a la misma hora cada día', 18),
(19, 19, 19, '2025-02-07', 'No cortar ni triturar la pastilla', 19),
(20, 20, 20, '2025-02-06', 'Tomar en la mañana con agua', 20);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `habitaciones`
--

CREATE TABLE `habitaciones` (
  `ID_Habitacion` int(11) NOT NULL,
  `ID_Paciente` int(11) DEFAULT NULL,
  `Numero_Habitacion` varchar(10) DEFAULT NULL,
  `Tipo_Habitacion` enum('Individual','Doble','Suite') DEFAULT NULL,
  `Estado_Habitacion` varchar(20) DEFAULT NULL,
  `Costo_Habitacion` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `habitaciones`
--

INSERT INTO `habitaciones` (`ID_Habitacion`, `ID_Paciente`, `Numero_Habitacion`, `Tipo_Habitacion`, `Estado_Habitacion`, `Costo_Habitacion`) VALUES
(1, 11, '101', 'Individual', 'Ocupada', 150000.00),
(2, 12, '102', 'Doble', 'Disponible', 200000.00),
(3, 13, '103', 'Suite', 'Ocupada', 350000.00),
(4, 14, '104', 'Individual', 'Disponible', 150000.00),
(5, 15, '105', 'Doble', 'Ocupada', 200000.00),
(6, 16, '106', 'Suite', 'Disponible', 350000.00),
(7, 17, '107', 'Individual', 'Ocupada', 150000.00),
(8, 18, '108', 'Doble', 'Disponible', 200000.00),
(9, 19, '109', 'Suite', 'Ocupada', 350000.00),
(10, 20, '110', 'Individual', 'Disponible', 150000.00),
(11, 21, '111', 'Doble', 'Ocupada', 200000.00),
(12, 22, '112', 'Suite', 'Disponible', 350000.00),
(13, 23, '113', 'Individual', 'Ocupada', 150000.00),
(14, 24, '114', 'Doble', 'Disponible', 200000.00),
(15, 25, '115', 'Suite', 'Ocupada', 350000.00),
(16, 26, '116', 'Individual', 'Disponible', 150000.00),
(17, 27, '117', 'Doble', 'Ocupada', 200000.00),
(18, 28, '118', 'Suite', 'Disponible', 350000.00),
(19, 29, '119', 'Individual', 'Ocupada', 150000.00),
(20, 30, '120', 'Doble', 'Disponible', 20000000.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historial_clinico`
--

CREATE TABLE `historial_clinico` (
  `ID_Historial` int(11) NOT NULL,
  `ID_Paciente` int(11) DEFAULT NULL,
  `Fecha_Historial` date DEFAULT NULL,
  `Descripción_Historial` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `historial_clinico`
--

INSERT INTO `historial_clinico` (`ID_Historial`, `ID_Paciente`, `Fecha_Historial`, `Descripción_Historial`) VALUES
(1, 11, '2024-01-10', 'Paciente con antecedentes de hipertensión, en control médico regular.'),
(2, 12, '2023-12-15', 'Historial de diabetes tipo 2, manejo con insulina.'),
(3, 13, '2024-02-05', 'Cirugía de apendicitis realizada con éxito, en recuperación.'),
(4, 14, '2023-11-20', 'Tratamiento para asma crónica, control con inhaladores.'),
(5, 15, '2024-01-25', 'Paciente con migrañas frecuentes, bajo tratamiento.'),
(6, 16, '2023-10-30', 'Fractura de tobillo, se realizó inmovilización y rehabilitación.'),
(7, 17, '2024-02-12', 'Historial de alergias estacionales, en tratamiento sintomático.'),
(8, 18, '2023-09-18', 'Paciente con obesidad, bajo dieta y ejercicio controlado.'),
(9, 19, '2023-11-05', 'Tratamiento para colesterol alto, en monitoreo médico.'),
(10, 20, '2024-01-08', 'Rehabilitación post-infarto en curso.'),
(11, 21, '2023-12-22', 'Paciente con depresión, en terapia psicológica y medicación.'),
(12, 22, '2023-10-15', 'Historial de infecciones urinarias recurrentes.'),
(13, 23, '2024-02-03', 'Tratamiento para artritis reumatoide, bajo control médico.'),
(14, 24, '2023-08-20', 'Cirugía de cataratas realizada con éxito.'),
(15, 25, '2024-01-30', 'Paciente con diagnóstico de gastritis crónica, en control.'),
(16, 26, '2023-09-10', 'Rehabilitación neurológica tras un accidente cerebrovascular.'),
(17, 27, '2024-02-14', 'Historial de dermatitis atópica, en tratamiento dermatológico.'),
(18, 28, '2023-11-27', 'Paciente con insuficiencia renal, en programa de diálisis.'),
(19, 29, '2023-12-05', 'Historial de tabaquismo, en tratamiento para cesación.'),
(20, 30, '2024-01-12', 'Paciente con anemia, en tratamiento con hierro.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `horarios_medicos`
--

CREATE TABLE `horarios_medicos` (
  `ID_Horario` int(11) NOT NULL,
  `ID_Medico` int(11) DEFAULT NULL,
  `Día` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo') DEFAULT NULL,
  `Hora_Inicio` time DEFAULT NULL,
  `Hora_Fin` time DEFAULT NULL,
  `Disponibilidad` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `horarios_medicos`
--

INSERT INTO `horarios_medicos` (`ID_Horario`, `ID_Medico`, `Día`, `Hora_Inicio`, `Hora_Fin`, `Disponibilidad`) VALUES
(1, 1, 'Lunes', '21:00:00', '22:00:00', 'Disponible'),
(2, 2, 'Martes', '09:00:00', '13:00:00', 'Disponible'),
(3, 3, 'Miércoles', '13:00:00', '13:00:00', 'Ocupado'),
(4, 4, 'Jueves', '11:00:00', '15:00:00', 'Disponible'),
(5, 5, 'Viernes', '12:00:00', '16:00:00', 'Disponible'),
(6, 6, 'Sábado', '08:00:00', '12:30:00', 'Ocupado'),
(7, 7, 'Lunes', '09:00:00', '13:00:00', 'Disponible'),
(8, 8, 'Martes', '10:30:00', '14:30:00', 'Disponible'),
(9, 9, 'Miércoles', '18:00:00', '22:00:00', 'Ocupado'),
(10, 10, 'Jueves', '09:45:00', '13:45:00', 'Disponible'),
(11, 11, 'Viernes', '10:00:00', '14:00:00', 'Disponible'),
(12, 12, 'Sábado', '11:30:00', '15:30:00', 'Disponible'),
(13, 13, 'Lunes', '08:15:00', '12:15:00', 'Ocupado'),
(14, 14, 'Martes', '09:30:00', '13:30:00', 'Disponible'),
(15, 15, 'Miércoles', '07:45:00', '11:45:00', 'Disponible'),
(16, 16, 'Jueves', '10:15:00', '14:15:00', 'Ocupado'),
(17, 17, 'Viernes', '08:45:00', '12:45:00', 'Disponible'),
(18, 18, 'Sábado', '09:30:00', '13:30:00', 'Disponible'),
(19, 19, 'Lunes', '10:00:00', '14:00:00', 'Disponible'),
(20, 20, 'Martes', '11:15:00', '15:15:00', 'Ocupado'),
(21, 21, 'Miércoles', '09:00:00', '13:00:00', 'Disponible'),
(22, 22, 'Jueves', '10:30:00', '14:30:00', 'Disponible'),
(23, 23, 'Viernes', '07:30:00', '11:30:00', 'Disponible'),
(24, 24, 'Sábado', '08:45:00', '12:45:00', 'Ocupado'),
(25, 25, 'Lunes', '09:15:00', '13:15:00', 'Disponible'),
(26, 26, 'Martes', '13:00:00', '14:00:00', 'Disponible');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `medicamentos`
--

CREATE TABLE `medicamentos` (
  `ID_Medicamento` int(11) NOT NULL,
  `Nombre_Medicamento` varchar(100) DEFAULT NULL,
  `Descripción_Medicamento` text DEFAULT NULL,
  `Dosis` varchar(50) DEFAULT NULL,
  `Frecuencia` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `medicamentos`
--

INSERT INTO `medicamentos` (`ID_Medicamento`, `Nombre_Medicamento`, `Descripción_Medicamento`, `Dosis`, `Frecuencia`) VALUES
(1, 'Paracetamol', 'Analgésico y antipirético para el dolor y la fiebre', '500 mg', 'Cada 8 horas'),
(2, 'Ibuprofeno', 'Antiinflamatorio no esteroideo para el dolor y la inflamación', '400 mg', 'Cada 6 horas'),
(3, 'Amoxicilina', 'Antibiótico de amplio espectro para infecciones bacterianas', '500 mg', 'Cada 12 horas'),
(4, 'Omeprazol', 'Inhibidor de la bomba de protones para reducir la acidez gástrica', '20 mg', 'Cada 24 horas'),
(5, 'Loratadina', 'Antihistamínico para alergias', '10 mg', 'Cada 24 horas'),
(6, 'Metformina', 'Antidiabético oral para la diabetes tipo 2', '850 mg', 'Cada 12 horas'),
(7, 'Atorvastatina', 'Reductor del colesterol en sangre', '10 mg', 'Cada 24 horas'),
(8, 'Salbutamol', 'Broncodilatador para el asma y enfermedades respiratorias', '100 mcg', 'Inhalador, cada 6 horas'),
(9, 'Ciprofloxacino', 'Antibiótico para infecciones bacterianas', '500 mg', 'Cada 12 horas'),
(10, 'Furosemida', 'Diurético para la hipertensión y edemas', '40 mg', 'Cada 24 horas'),
(11, 'Diazepam', 'Ansiolítico y relajante muscular', '5 mg', 'Cada 12 horas'),
(12, 'Clonazepam', 'Benzodiacepina para trastornos de ansiedad', '2 mg', 'Cada 12 horas'),
(13, 'Losartán', 'Antihipertensivo para la presión arterial alta', '50 mg', 'Cada 24 horas'),
(14, 'Aspirina', 'Analgésico y antiagregante plaquetario', '100 mg', 'Cada 24 horas'),
(15, 'Ranitidina', 'Inhibidor de ácido gástrico', '150 mg', 'Cada 12 horas'),
(16, 'Prednisona', 'Corticosteroide para inflamaciones y alergias', '10 mg', 'Cada 24 horas'),
(17, 'Dexametasona', 'Corticosteroide para inflamaciones graves', '4 mg', 'Cada 24 horas'),
(18, 'Azitromicina', 'Antibiótico de amplio espectro', '500 mg', 'Cada 24 horas por 3 días'),
(19, 'Enalapril', 'Antihipertensivo para la presión arterial alta', '10 mg', 'Cada 12 horas'),
(20, 'Sertralina', 'Antidepresivo inhibidor de la recaptación de serotonina', '50 mg', 'Cada 24 horas'),
(21, 'Fluoxetina', 'Antidepresivo para la depresión y ansiedad', '20 mg', 'Cada 24 horas'),
(22, 'Warfarina', 'Anticoagulante para evitar trombos', '5 mg', 'Cada 24 horas'),
(23, 'Ketorolaco', 'Analgésico potente para el dolor moderado a severo', '10 mg', 'Cada 6 horas'),
(24, 'Insulina Glargina', 'Hormona para el control de la glucosa en diabetes', '10 UI', 'Cada 24 horas'),
(25, 'Metoclopramida', 'Antiemético para las náuseas y vómitos', '10 mg', 'Cada 8 horas'),
(26, 'Propranolol', 'Betabloqueante para la presión arterial y arritmias', '40 mg', 'Cada 12 horas'),
(27, 'Carbamazepina', 'Anticonvulsivante y estabilizador del estado de ánimo', '200 mg', 'Cada 12 horas'),
(28, 'Tramadol', 'Opioide para el dolor moderado a severo', '50 mg', 'Cada 8 horas'),
(29, 'Levotiroxina', 'Hormona tiroidea para el hipotiroidismo', '50 mcg', 'Cada 24 horas'),
(30, 'Morfina', 'Analgésico opioide para el dolor severo', '10 mg', 'Cada 12 horas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `medicos`
--

CREATE TABLE `medicos` (
  `ID_Medico` int(11) NOT NULL,
  `Nombre` varchar(50) DEFAULT NULL,
  `Apellidos` varchar(50) DEFAULT NULL,
  `Especialidad` varchar(100) DEFAULT NULL,
  `Telefono` varchar(20) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Numero_Licencia` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `medicos`
--

INSERT INTO `medicos` (`ID_Medico`, `Nombre`, `Apellidos`, `Especialidad`, `Telefono`, `Email`, `Numero_Licencia`) VALUES
(1, 'sofonias', 'mena', 'Cardiología', '3001234567', 'juan.sofonias@gmail.com', 'LIC123456'),
(2, 'cristomina', 'González', 'Neurología', '3012345678', 'cristomina.gonzalez@gmail.com', 'LIC234567'),
(3, 'Carlos', 'Ramírez', 'Pediatría', '3023456789', 'carlos.ramirez@gamil.com', 'LIC345678'),
(4, 'Ana', 'Martínez', 'Dermatología', '3034567890', 'ana.martinez@gmail.com', 'LIC456789'),
(5, 'Luis', 'Fernández', 'Ginecología', '3045678901', 'luis.fernandez@gmail.com', 'LIC567890'),
(6, 'Elena', 'Sánchez', 'Oftalmología', '3056789012', 'elena.sanchez@gmail.com', 'LIC678901'),
(7, 'Ricardo', 'López', 'Traumatología', '3067890123', 'ricardo.lopez@gmail.com', 'LIC789012'),
(8, 'Diana', 'Torres', 'Oncología', '3078901234', 'diana.torres@gmail.com', 'LIC890123'),
(9, 'Gabriel', 'Vargas', 'Psiquiatría', '3089012345', 'gabriel.vargas@gmail.com', 'LIC901234'),
(10, 'Paola', 'Ortega', 'Urología', '3090123456', 'paola.ortega@gmail.com', 'LIC012345'),
(11, 'Andrés', 'Jiménez', 'Gastroenterología', '3101234567', 'andres.jimenez@gmail.com', 'LIC123457'),
(12, 'Sofía', 'Morales', 'Endocrinología', '3112345678', 'sofia.morales@gmail.com', 'LIC234568'),
(13, 'Fernando', 'Reyes', 'Nefrología', '3123456789', 'fernando.reyes@gmail.com', 'LIC345679'),
(14, 'Valeria', 'Navarro', 'Neumología', '3134567890', 'valeria.navarro@gmail.com', 'LIC456780'),
(15, 'Daniel', 'Suárez', 'Reumatología', '3145678901', 'daniel.suarez@gmail.com', 'LIC567891'),
(16, 'Adriana', 'Cortés', 'Hematología', '3156789012', 'adriana.cortes@example.com', 'LIC678902'),
(17, 'José', 'Mendoza', 'Otorrinolaringología', '3167890123', 'jose.mendoza@example.com', 'LIC789013'),
(18, 'Carolina', 'Guzmán', 'Cirugía General', '3178901234', 'carolina.guzman@example.com', 'LIC890124'),
(19, 'Miguel', 'Peña', 'Medicina Interna', '3189012345', 'miguel.pena@example.com', 'LIC901235'),
(20, 'Natalia', 'Castillo', 'Anestesiología', '3190123456', 'natalia.castillo@example.com', 'LIC012346'),
(21, 'Hugo', 'Silva', 'Radiología', '3201234567', 'hugo.silva@example.com', 'LIC123458'),
(22, 'Cecilia', 'Álvarez', 'Geriatría', '3212345678', 'cecilia.alvarez@example.com', 'LIC234569'),
(23, 'Roberto', 'Ríos', 'Cirugía Plástica', '3223456789', 'roberto.rios@example.com', 'LIC345680'),
(24, 'Laura', 'Domínguez', 'Medicina del Deporte', '3234567890', 'laura.dominguez@example.com', 'LIC456781'),
(25, 'Javier', 'Espinoza', 'Medicina General', '3245678901', 'javier.espinoza@example.com', 'LIC567892'),
(26, 'Verónica', 'Mejía', 'Odontología', '3256789012', 'veronica.mejia@example.com', 'LIC678903'),
(27, 'Germán', 'Valencia', 'Nutrición', '3267890123', 'german.valencia@example.com', 'LIC789014'),
(28, 'Liliana', 'Zapata', 'Medicina Física y Rehabilitación', '3278901234', 'liliana.zapata@example.com', 'LIC890125'),
(29, 'Eduardo', 'Salazar', 'Genética Médica', '3289012345', 'eduardo.salazar@example.com', 'LIC901236'),
(30, 'Marcela', 'Hernández', 'Alergología', '3290123456', 'marcela.hernandez@example.com', 'LIC012347');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pacientes`
--

CREATE TABLE `pacientes` (
  `ID_Paciente` int(11) NOT NULL,
  `Nombre` varchar(50) DEFAULT NULL,
  `Apellido` varchar(50) DEFAULT NULL,
  `Fecha_Nacimiento` date DEFAULT NULL,
  `barrio` varchar(100) DEFAULT NULL,
  `Ciudad` varchar(50) DEFAULT NULL,
  `Teléfono` varchar(20) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `tipo_sangre` varchar(5) DEFAULT NULL,
  `eps` varchar(100) DEFAULT NULL,
  `Genero` enum('Masculino','Femenino','Otro') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pacientes`
--

INSERT INTO `pacientes` (`ID_Paciente`, `Nombre`, `Apellido`, `Fecha_Nacimiento`, `barrio`, `Ciudad`, `Teléfono`, `Email`, `tipo_sangre`, `eps`, `Genero`) VALUES
(1, 'angel', 'serna', '1978-05-04', 'porvenir', 'quibdo', '3137315349', 'angel@gmail.com', 'o+', 'comfachoco', 'Masculino'),
(2, 'jiseth', 'cordoba', '1998-01-25', 'porvenir', 'Medellín', '3137315348', 'jiseth@gmail.com', 'o+', 'sanitas', 'Femenino'),
(3, 'denzel', 'mena', '2004-02-17', 'paz', 'quibdo', '3125875978', 'denzel@gmail.com', 'o-', 'sanitas', 'Masculino'),
(11, 'Carlos', 'Santos', '1985-07-21', 'San Fernando', 'Bogotá', '3216549870', 'carlos.santos@email.com', 'O+', 'Compensar', 'Masculino'),
(12, 'Luisa', 'Fernandez', '1992-11-30', 'Villa del Rosario', 'Medellín', '3125678945', 'luisa.fernandez@email.com', 'A-', 'Sura', 'Femenino'),
(13, 'Fernando', 'Luna', '1980-03-14', 'Santa Cruz', 'Cali', '3159871234', 'fernando.luna@email.com', 'B+', 'Salud Total', 'Masculino'),
(14, 'Margarita', 'Rojas', '1996-09-22', 'Los Almendros', 'Barranquilla', '3101234567', 'margarita.rojas@email.com', 'AB-', 'Sanitas', 'Femenino'),
(15, 'Jorge', 'Castro', '1988-05-10', 'Los Naranjos', 'Cartagena', '3204567891', 'jorge.castro@email.com', 'O-', 'Coomeva', 'Masculino'),
(16, 'Andrea', 'Ramirez', '1993-12-08', 'La Esperanza', 'Bucaramanga', '3198745632', 'andrea.ramirez@email.com', 'A+', 'Nueva EPS', 'Femenino'),
(17, 'Sebastián', 'Mendoza', '1975-04-25', 'Villa Nueva', 'Manizales', '3119854321', 'sebastian.mendoza@email.com', 'B-', 'Medimás', 'Masculino'),
(18, 'Natalia', 'Ortega', '1989-08-19', 'San Joaquín', 'Pereira', '3227654321', 'natalia.ortega@email.com', 'AB+', 'Salud Total', 'Femenino'),
(19, 'Raúl', 'Peña', '2000-02-17', 'La Floresta', 'Ibagué', '3136789543', 'raul.pena@email.com', 'O+', 'Sura', 'Masculino'),
(20, 'Camila', 'Hernández', '1995-06-28', 'El Prado', 'Cúcuta', '3187654321', 'camila.hernandez@email.com', 'A-', 'Compensar', 'Femenino'),
(21, 'Ricardo', 'Lopez', '1983-09-15', 'Villa del Mar', 'Armenia', '3175647382', 'ricardo.lopez@email.com', 'B+', 'Sanitas', 'Masculino'),
(22, 'Tatiana', 'Gomez', '1991-07-04', 'San Antonio', 'Tunja', '3147852369', 'tatiana.gomez@email.com', 'O-', 'Nueva EPS', 'Femenino'),
(23, 'Hugo', 'Diaz', '1987-11-23', 'Santa Maria', 'Villavicencio', '3105678234', 'hugo.diaz@email.com', 'A+', 'Coomeva', 'Masculino'),
(24, 'Patricia', 'Vargas', '1979-01-30', 'Los Pinos', 'Popayán', '3162347895', 'patricia.vargas@email.com', 'B-', 'Medimás', 'Femenino'),
(25, 'David', 'Cruz', '1994-12-12', 'Las Palmas', 'Santa Marta', '3127894561', 'david.cruz@email.com', 'AB+', 'Salud Total', 'Masculino'),
(26, 'Lorena', 'Jimenez', '1986-03-18', 'El Bosque', 'Neiva', '3196785421', 'lorena.jimenez@email.com', 'O+', 'Sura', 'Femenino'),
(27, 'Esteban', 'Muñoz', '1998-09-25', 'Villa Bonita', 'Montería', '3112349876', 'esteban.munoz@email.com', 'A-', 'Compensar', 'Masculino'),
(28, 'Rosa', 'Galeano', '1972-06-07', 'San Ignacio', 'Pasto', '3135679821', 'rosa.galeano@email.com', 'B+', 'Sanitas', 'Femenino'),
(29, 'Andrés', 'Salazar', '1982-10-16', 'Los Cedros', 'Sincelejo', '3176789541', 'andres.salazar@email.com', 'O-', 'Nueva EPS', 'Masculino'),
(30, 'Isabela', 'Ruiz', '1990-05-03', 'La Riviera', 'Riohacha', '3152347865', 'isabela.ruiz@email.com', 'A+', 'Coomeva', 'Femenino');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tratamientos`
--

CREATE TABLE `tratamientos` (
  `ID_Tratamiento` int(11) NOT NULL,
  `Nombre_Tratamiento` varchar(100) DEFAULT NULL,
  `Descripción_Tratamiento` text DEFAULT NULL,
  `ID_Historial` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_citas_canceladas`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_citas_canceladas` (
`ID_Cita` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`Fecha_Cita` date
,`Hora_Cita` time
,`Motivo_Cita` text
,`Estado_Cita` enum('Pendiente','Confirmada','Cancelada')
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_citas_cardiologia`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_citas_cardiologia` (
`ID_Cita` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`Fecha_Cita` date
,`Hora_Cita` time
,`Motivo_Cita` text
,`Estado_Cita` enum('Pendiente','Confirmada','Cancelada')
,`Nombre_Medico` varchar(50)
,`Apellido_Medico` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_citas_chequeo_general`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_citas_chequeo_general` (
`ID_Cita` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`Fecha_Cita` date
,`Hora_Cita` time
,`Motivo_Cita` text
,`Estado_Cita` enum('Pendiente','Confirmada','Cancelada')
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_citas_confirmadas`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_citas_confirmadas` (
`ID_Cita` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`Fecha_Cita` date
,`Hora_Cita` time
,`Motivo_Cita` text
,`Estado_Cita` enum('Pendiente','Confirmada','Cancelada')
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_citas_ginecologia`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_citas_ginecologia` (
`ID_Cita` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`Fecha_Cita` date
,`Hora_Cita` time
,`Motivo_Cita` text
,`Estado_Cita` enum('Pendiente','Confirmada','Cancelada')
,`Nombre_Medico` varchar(50)
,`Apellido_Medico` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_citas_manana`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_citas_manana` (
`ID_Cita` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`Fecha_Cita` date
,`Hora_Cita` time
,`Motivo_Cita` text
,`Estado_Cita` enum('Pendiente','Confirmada','Cancelada')
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_citas_medicas_generales`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_citas_medicas_generales` (
`ID_Cita` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`Fecha_Cita` date
,`Hora_Cita` time
,`Motivo_Cita` text
,`Estado_Cita` enum('Pendiente','Confirmada','Cancelada')
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_citas_medicos_a`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_citas_medicos_a` (
`ID_Cita` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`Fecha_Cita` date
,`Hora_Cita` time
,`Motivo_Cita` text
,`Estado_Cita` enum('Pendiente','Confirmada','Cancelada')
,`Nombre_Medico` varchar(50)
,`Apellido_Medico` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_citas_oftalmologia`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_citas_oftalmologia` (
`ID_Cita` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`Fecha_Cita` date
,`Hora_Cita` time
,`Motivo_Cita` text
,`Estado_Cita` enum('Pendiente','Confirmada','Cancelada')
,`Nombre_Medico` varchar(50)
,`Especialidad` varchar(100)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_citas_pacientes_apellido_z`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_citas_pacientes_apellido_z` (
`ID_Cita` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`Fecha_Cita` date
,`Hora_Cita` time
,`Motivo_Cita` text
,`Estado_Cita` enum('Pendiente','Confirmada','Cancelada')
,`Nombre_Paciente` varchar(50)
,`Apellido_Paciente` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_citas_pacientes_mayores`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_citas_pacientes_mayores` (
`ID_Cita` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`Fecha_Cita` date
,`Hora_Cita` time
,`Motivo_Cita` text
,`Estado_Cita` enum('Pendiente','Confirmada','Cancelada')
,`Nombre_Paciente` varchar(50)
,`Apellido_Paciente` varchar(50)
,`Edad` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_citas_pacientes_rh_negativo`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_citas_pacientes_rh_negativo` (
`ID_Cita` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`Fecha_Cita` date
,`Hora_Cita` time
,`Motivo_Cita` text
,`Estado_Cita` enum('Pendiente','Confirmada','Cancelada')
,`Nombre_Paciente` varchar(50)
,`tipo_sangre` varchar(5)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_citas_pendientes`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_citas_pendientes` (
`ID_Cita` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`Fecha_Cita` date
,`Hora_Cita` time
,`Motivo_Cita` text
,`Estado_Cita` enum('Pendiente','Confirmada','Cancelada')
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_citas_proxima_semana`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_citas_proxima_semana` (
`ID_Cita` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`Fecha_Cita` date
,`Hora_Cita` time
,`Motivo_Cita` text
,`Estado_Cita` enum('Pendiente','Confirmada','Cancelada')
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_citas_psiquiatria`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_citas_psiquiatria` (
`ID_Cita` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`Fecha_Cita` date
,`Hora_Cita` time
,`Motivo_Cita` text
,`Estado_Cita` enum('Pendiente','Confirmada','Cancelada')
,`Nombre_Medico` varchar(50)
,`Apellido_Medico` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_distribucion_horarios`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_distribucion_horarios` (
`Día` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo')
,`Total` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_habitaciones_asignadas`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_habitaciones_asignadas` (
`ID_Habitacion` int(11)
,`ID_Paciente` int(11)
,`Numero_Habitacion` varchar(10)
,`Tipo_Habitacion` enum('Individual','Doble','Suite')
,`Estado_Habitacion` varchar(20)
,`Costo_Habitacion` decimal(10,2)
,`Nombre_Paciente` varchar(50)
,`Apellido_Paciente` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_habitaciones_baratas`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_habitaciones_baratas` (
`ID_Habitacion` int(11)
,`ID_Paciente` int(11)
,`Numero_Habitacion` varchar(10)
,`Tipo_Habitacion` enum('Individual','Doble','Suite')
,`Estado_Habitacion` varchar(20)
,`Costo_Habitacion` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_habitaciones_costosas`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_habitaciones_costosas` (
`ID_Habitacion` int(11)
,`ID_Paciente` int(11)
,`Numero_Habitacion` varchar(10)
,`Tipo_Habitacion` enum('Individual','Doble','Suite')
,`Estado_Habitacion` varchar(20)
,`Costo_Habitacion` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_habitaciones_disponibles`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_habitaciones_disponibles` (
`ID_Habitacion` int(11)
,`ID_Paciente` int(11)
,`Numero_Habitacion` varchar(10)
,`Tipo_Habitacion` enum('Individual','Doble','Suite')
,`Estado_Habitacion` varchar(20)
,`Costo_Habitacion` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_habitaciones_disponibles_economicas`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_habitaciones_disponibles_economicas` (
`ID_Habitacion` int(11)
,`ID_Paciente` int(11)
,`Numero_Habitacion` varchar(10)
,`Tipo_Habitacion` enum('Individual','Doble','Suite')
,`Estado_Habitacion` varchar(20)
,`Costo_Habitacion` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_habitaciones_ocupadas`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_habitaciones_ocupadas` (
`ID_Habitacion` int(11)
,`ID_Paciente` int(11)
,`Numero_Habitacion` varchar(10)
,`Tipo_Habitacion` enum('Individual','Doble','Suite')
,`Estado_Habitacion` varchar(20)
,`Costo_Habitacion` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_habitaciones_pacientes_frecuentes`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_habitaciones_pacientes_frecuentes` (
`ID_Habitacion` int(11)
,`ID_Paciente` int(11)
,`Numero_Habitacion` varchar(10)
,`Tipo_Habitacion` enum('Individual','Doble','Suite')
,`Estado_Habitacion` varchar(20)
,`Costo_Habitacion` decimal(10,2)
,`Nombre_Paciente` varchar(50)
,`Apellido_Paciente` varchar(50)
,`Total_Hospitalizaciones` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_habitaciones_suite`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_habitaciones_suite` (
`ID_Habitacion` int(11)
,`ID_Paciente` int(11)
,`Numero_Habitacion` varchar(10)
,`Tipo_Habitacion` enum('Individual','Doble','Suite')
,`Estado_Habitacion` varchar(20)
,`Costo_Habitacion` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_historiales_descripciones_largas`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_historiales_descripciones_largas` (
`ID_Historial` int(11)
,`ID_Paciente` int(11)
,`Fecha_Historial` date
,`Descripción_Historial` text
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_historiales_por_paciente`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_historiales_por_paciente` (
`ID_Historial` int(11)
,`ID_Paciente` int(11)
,`Fecha_Historial` date
,`Descripción_Historial` text
,`Nombre` varchar(50)
,`Apellido` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_historiales_recientes`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_historiales_recientes` (
`ID_Historial` int(11)
,`ID_Paciente` int(11)
,`Fecha_Historial` date
,`Descripción_Historial` text
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_horarios_8am`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_horarios_8am` (
`ID_Horario` int(11)
,`ID_Medico` int(11)
,`Día` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo')
,`Hora_Inicio` time
,`Hora_Fin` time
,`Disponibilidad` varchar(20)
,`Nombre` varchar(50)
,`Apellidos` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_horarios_cardiologia`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_horarios_cardiologia` (
`ID_Horario` int(11)
,`ID_Medico` int(11)
,`Día` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo')
,`Hora_Inicio` time
,`Hora_Fin` time
,`Disponibilidad` varchar(20)
,`Nombre` varchar(50)
,`Apellidos` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_horarios_con_especialidad`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_horarios_con_especialidad` (
`ID_Horario` int(11)
,`ID_Medico` int(11)
,`Día` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo')
,`Hora_Inicio` time
,`Hora_Fin` time
,`Disponibilidad` varchar(20)
,`Nombre` varchar(50)
,`Apellidos` varchar(50)
,`Especialidad` varchar(100)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_horarios_cortos`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_horarios_cortos` (
`ID_Horario` int(11)
,`ID_Medico` int(11)
,`Día` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo')
,`Hora_Inicio` time
,`Hora_Fin` time
,`Disponibilidad` varchar(20)
,`Duracion` time
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_horarios_disponibles`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_horarios_disponibles` (
`ID_Horario` int(11)
,`ID_Medico` int(11)
,`Día` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo')
,`Hora_Inicio` time
,`Hora_Fin` time
,`Disponibilidad` varchar(20)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_horarios_disponibles_martes`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_horarios_disponibles_martes` (
`ID_Horario` int(11)
,`ID_Medico` int(11)
,`Día` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo')
,`Hora_Inicio` time
,`Hora_Fin` time
,`Disponibilidad` varchar(20)
,`Nombre` varchar(50)
,`Apellidos` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_horarios_fines_de_semana`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_horarios_fines_de_semana` (
`ID_Horario` int(11)
,`ID_Medico` int(11)
,`Día` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo')
,`Hora_Inicio` time
,`Hora_Fin` time
,`Disponibilidad` varchar(20)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_horarios_intermedios`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_horarios_intermedios` (
`ID_Horario` int(11)
,`ID_Medico` int(11)
,`Día` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo')
,`Hora_Inicio` time
,`Hora_Fin` time
,`Disponibilidad` varchar(20)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_horarios_jornada_completa`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_horarios_jornada_completa` (
`ID_Horario` int(11)
,`ID_Medico` int(11)
,`Día` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo')
,`Hora_Inicio` time
,`Hora_Fin` time
,`Disponibilidad` varchar(20)
,`Duracion` time
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_horarios_lunes`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_horarios_lunes` (
`ID_Horario` int(11)
,`ID_Medico` int(11)
,`Día` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo')
,`Hora_Inicio` time
,`Hora_Fin` time
,`Disponibilidad` varchar(20)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_horarios_manana`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_horarios_manana` (
`ID_Horario` int(11)
,`ID_Medico` int(11)
,`Día` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo')
,`Hora_Inicio` time
,`Hora_Fin` time
,`Disponibilidad` varchar(20)
,`Nombre_Medico` varchar(50)
,`Apellido_Medico` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_horarios_matutinos`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_horarios_matutinos` (
`ID_Horario` int(11)
,`ID_Medico` int(11)
,`Día` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo')
,`Hora_Inicio` time
,`Hora_Fin` time
,`Disponibilidad` varchar(20)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_horarios_medicos_experimentados`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_horarios_medicos_experimentados` (
`ID_Horario` int(11)
,`ID_Medico` int(11)
,`Día` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo')
,`Hora_Inicio` time
,`Hora_Fin` time
,`Disponibilidad` varchar(20)
,`Nombre` varchar(50)
,`Apellidos` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_horarios_medicos_nombres`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_horarios_medicos_nombres` (
`ID_Horario` int(11)
,`ID_Medico` int(11)
,`Día` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo')
,`Hora_Inicio` time
,`Hora_Fin` time
,`Disponibilidad` varchar(20)
,`Nombre` varchar(50)
,`Apellidos` varchar(50)
,`Especialidad` varchar(100)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_horarios_neurologia`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_horarios_neurologia` (
`ID_Horario` int(11)
,`ID_Medico` int(11)
,`Día` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo')
,`Hora_Inicio` time
,`Hora_Fin` time
,`Disponibilidad` varchar(20)
,`Nombre` varchar(50)
,`Apellidos` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_horarios_ocupados`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_horarios_ocupados` (
`ID_Horario` int(11)
,`ID_Medico` int(11)
,`Día` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo')
,`Hora_Inicio` time
,`Hora_Fin` time
,`Disponibilidad` varchar(20)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_horarios_por_dia`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_horarios_por_dia` (
`Día` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo')
,`Total_Horarios` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_horarios_por_especialidad`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_horarios_por_especialidad` (
`ID_Horario` int(11)
,`ID_Medico` int(11)
,`Día` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo')
,`Hora_Inicio` time
,`Hora_Fin` time
,`Disponibilidad` varchar(20)
,`Nombre_Medico` varchar(50)
,`Apellido_Medico` varchar(50)
,`Especialidad` varchar(100)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_horarios_por_medico`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_horarios_por_medico` (
`ID_Medico` int(11)
,`Total_Horarios` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_horarios_tarde`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_horarios_tarde` (
`ID_Horario` int(11)
,`ID_Medico` int(11)
,`Día` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo')
,`Hora_Inicio` time
,`Hora_Fin` time
,`Disponibilidad` varchar(20)
,`Nombre` varchar(50)
,`Apellidos` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_horarios_tardios`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_horarios_tardios` (
`ID_Horario` int(11)
,`ID_Medico` int(11)
,`Día` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo')
,`Hora_Inicio` time
,`Hora_Fin` time
,`Disponibilidad` varchar(20)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_horarios_tempranos`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_horarios_tempranos` (
`ID_Horario` int(11)
,`ID_Medico` int(11)
,`Día` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo')
,`Hora_Inicio` time
,`Hora_Fin` time
,`Disponibilidad` varchar(20)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_horarios_vespertinos`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_horarios_vespertinos` (
`ID_Horario` int(11)
,`ID_Medico` int(11)
,`Día` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo')
,`Hora_Inicio` time
,`Hora_Fin` time
,`Disponibilidad` varchar(20)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_medicos_disponibles_viernes`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_medicos_disponibles_viernes` (
`ID_Horario` int(11)
,`ID_Medico` int(11)
,`Día` enum('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo')
,`Hora_Inicio` time
,`Hora_Fin` time
,`Disponibilidad` varchar(20)
,`Nombre` varchar(50)
,`Apellidos` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_medicos_horarios_continuos`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_medicos_horarios_continuos` (
`ID_Medico` int(11)
,`Cantidad_Horarios` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_medicos_mas_disponibles`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_medicos_mas_disponibles` (
`ID_Medico` int(11)
,`Disponibles` decimal(22,0)
,`Ocupados` decimal(22,0)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_medicos_mas_horarios`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_medicos_mas_horarios` (
`ID_Medico` int(11)
,`Total_Horarios` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_medicos_mas_lunes`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_medicos_mas_lunes` (
`ID_Medico` int(11)
,`Total` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_medicos_todos_los_dias`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_medicos_todos_los_dias` (
`ID_Medico` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_promedio_duracion_horarios`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_promedio_duracion_horarios` (
`ID_Medico` int(11)
,`Promedio_Minutos` decimal(24,4)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_ultima_consulta_paciente`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_ultima_consulta_paciente` (
`ID_Historial` int(11)
,`ID_Paciente` int(11)
,`Fecha_Historial` date
,`Descripción_Historial` text
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_cantidad_formulas_medicamento`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_cantidad_formulas_medicamento` (
`ID_Medicamento` int(11)
,`Total_Prescripciones` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_facturas_cardiologia`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_facturas_cardiologia` (
`ID_Factura` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`ID_Cita` int(11)
,`Fecha_Factura` date
,`pago_Total` decimal(10,2)
,`Descripción` text
,`Metodo_Pago` enum('Efectivo','Tarjeta','Transferencia')
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_facturas_citas_canceladas`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_facturas_citas_canceladas` (
`ID_Factura` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`ID_Cita` int(11)
,`Fecha_Factura` date
,`pago_Total` decimal(10,2)
,`Descripción` text
,`Metodo_Pago` enum('Efectivo','Tarjeta','Transferencia')
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_facturas_pacientes_hombres`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_facturas_pacientes_hombres` (
`ID_Factura` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`ID_Cita` int(11)
,`Fecha_Factura` date
,`pago_Total` decimal(10,2)
,`Descripción` text
,`Metodo_Pago` enum('Efectivo','Tarjeta','Transferencia')
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_formulas_ansiliticos`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_formulas_ansiliticos` (
`ID_Formula` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`Fecha_Formula` date
,`Indicaciones` text
,`ID_Medicamento` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_formulas_antiinflamatorios`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_formulas_antiinflamatorios` (
`ID_Formula` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`Fecha_Formula` date
,`Indicaciones` text
,`ID_Medicamento` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_formulas_controladas`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_formulas_controladas` (
`ID_Formula` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`Fecha_Formula` date
,`Indicaciones` text
,`ID_Medicamento` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_formulas_hipertension`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_formulas_hipertension` (
`ID_Formula` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`Fecha_Formula` date
,`Indicaciones` text
,`ID_Medicamento` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_formulas_medicas_detalle`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_formulas_medicas_detalle` (
`ID_Formula` int(11)
,`Fecha_Formula` date
,`Indicaciones` text
,`ID_Paciente` int(11)
,`Nombre_Paciente` varchar(50)
,`Apellido_Paciente` varchar(50)
,`ID_Medico` int(11)
,`Nombre_Medico` varchar(50)
,`Apellido_Medico` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_formulas_ordenadas`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_formulas_ordenadas` (
`ID_Formula` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`Fecha_Formula` date
,`Indicaciones` text
,`ID_Medicamento` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_formulas_pacientes_hombres`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_formulas_pacientes_hombres` (
`ID_Formula` int(11)
,`Fecha_Formula` date
,`Indicaciones` text
,`ID_Medicamento` int(11)
,`ID_Medico` int(11)
,`ID_Paciente` int(11)
,`Nombre_Paciente` varchar(50)
,`Apellido_Paciente` varchar(50)
,`Genero` enum('Masculino','Femenino','Otro')
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_formulas_pacientes_jovenes`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_formulas_pacientes_jovenes` (
`ID_Formula` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`Fecha_Formula` date
,`Indicaciones` text
,`ID_Medicamento` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_formulas_paracetamol`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_formulas_paracetamol` (
`ID_Formula` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`Fecha_Formula` date
,`Indicaciones` text
,`ID_Medicamento` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_formulas_por_eps`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_formulas_por_eps` (
`EPS` varchar(100)
,`Total_Formulas` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_formulas_por_especialidad`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_formulas_por_especialidad` (
`Especialidad` varchar(100)
,`Total_Formulas` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_formulas_por_paciente`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_formulas_por_paciente` (
`ID_Formula` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`Fecha_Formula` date
,`Indicaciones` text
,`ID_Medicamento` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_formulas_ultima_semana`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_formulas_ultima_semana` (
`ID_Formula` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`Fecha_Formula` date
,`Indicaciones` text
,`ID_Medicamento` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_formulas_ultimos_6_meses`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_formulas_ultimos_6_meses` (
`ID_Formula` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`Fecha_Formula` date
,`Indicaciones` text
,`ID_Medicamento` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_formulas_ultimo_mes`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_formulas_ultimo_mes` (
`ID_Formula` int(11)
,`ID_Paciente` int(11)
,`ID_Medico` int(11)
,`Fecha_Formula` date
,`Indicaciones` text
,`ID_Medicamento` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_medicamentos_mas_usados`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_medicamentos_mas_usados` (
`ID_Medicamento` int(11)
,`Total_Prescripciones` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_medicamentos_neurologia`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_medicamentos_neurologia` (
`ID_Medicamento` int(11)
,`Total_Prescripciones` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_medicamentos_unica_vez`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_medicamentos_unica_vez` (
`ID_Medicamento` int(11)
,`Total_Prescripciones` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_medicos_aspirina`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_medicos_aspirina` (
`ID_Medico` int(11)
,`Nombre` varchar(50)
,`Apellidos` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_medicos_cardiologia`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_medicos_cardiologia` (
`ID_Medico` int(11)
,`Nombre` varchar(50)
,`Apellidos` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_medicos_frecuentes`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_medicos_frecuentes` (
`ID_Medico` int(11)
,`Total_Formulas` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_medicos_mas_prescripciones`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_medicos_mas_prescripciones` (
`ID_Medico` int(11)
,`Total_Formulas` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_medicos_pacientes_recurrentes`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_medicos_pacientes_recurrentes` (
`ID_Medico` int(11)
,`ID_Paciente` int(11)
,`Veces_Atendido` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_pacientes_antibioticos`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_pacientes_antibioticos` (
`ID_Paciente` int(11)
,`Nombre` varchar(50)
,`Apellido` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_pacientes_frecuentes`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_pacientes_frecuentes` (
`ID_Paciente` int(11)
,`Total_Formulas` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_pacientes_frecuentes_mes`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_pacientes_frecuentes_mes` (
`ID_Paciente` int(11)
,`Total_Formulas` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_pacientes_ibuprofeno`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_pacientes_ibuprofeno` (
`ID_Paciente` int(11)
,`Nombre` varchar(50)
,`Apellido` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `v_pacientes_prescripciones_repetidas`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `v_pacientes_prescripciones_repetidas` (
`ID_Paciente` int(11)
,`ID_Medicamento` int(11)
,`Veces_Prescrito` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_citas_canceladas`
--
DROP TABLE IF EXISTS `vista_citas_canceladas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_citas_canceladas`  AS SELECT `citas`.`ID_Cita` AS `ID_Cita`, `citas`.`ID_Paciente` AS `ID_Paciente`, `citas`.`ID_Medico` AS `ID_Medico`, `citas`.`Fecha_Cita` AS `Fecha_Cita`, `citas`.`Hora_Cita` AS `Hora_Cita`, `citas`.`Motivo_Cita` AS `Motivo_Cita`, `citas`.`Estado_Cita` AS `Estado_Cita` FROM `citas` WHERE `citas`.`Estado_Cita` = 'Cancelada' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_citas_cardiologia`
--
DROP TABLE IF EXISTS `vista_citas_cardiologia`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_citas_cardiologia`  AS SELECT `c`.`ID_Cita` AS `ID_Cita`, `c`.`ID_Paciente` AS `ID_Paciente`, `c`.`ID_Medico` AS `ID_Medico`, `c`.`Fecha_Cita` AS `Fecha_Cita`, `c`.`Hora_Cita` AS `Hora_Cita`, `c`.`Motivo_Cita` AS `Motivo_Cita`, `c`.`Estado_Cita` AS `Estado_Cita`, `m`.`Nombre` AS `Nombre_Medico`, `m`.`Apellidos` AS `Apellido_Medico` FROM (`citas` `c` join `medicos` `m` on(`c`.`ID_Medico` = `m`.`ID_Medico`)) WHERE `m`.`Especialidad` = 'Cardiología' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_citas_chequeo_general`
--
DROP TABLE IF EXISTS `vista_citas_chequeo_general`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_citas_chequeo_general`  AS SELECT `citas`.`ID_Cita` AS `ID_Cita`, `citas`.`ID_Paciente` AS `ID_Paciente`, `citas`.`ID_Medico` AS `ID_Medico`, `citas`.`Fecha_Cita` AS `Fecha_Cita`, `citas`.`Hora_Cita` AS `Hora_Cita`, `citas`.`Motivo_Cita` AS `Motivo_Cita`, `citas`.`Estado_Cita` AS `Estado_Cita` FROM `citas` WHERE `citas`.`Motivo_Cita` like '%Chequeo%' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_citas_confirmadas`
--
DROP TABLE IF EXISTS `vista_citas_confirmadas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_citas_confirmadas`  AS SELECT `citas`.`ID_Cita` AS `ID_Cita`, `citas`.`ID_Paciente` AS `ID_Paciente`, `citas`.`ID_Medico` AS `ID_Medico`, `citas`.`Fecha_Cita` AS `Fecha_Cita`, `citas`.`Hora_Cita` AS `Hora_Cita`, `citas`.`Motivo_Cita` AS `Motivo_Cita`, `citas`.`Estado_Cita` AS `Estado_Cita` FROM `citas` WHERE `citas`.`Estado_Cita` = 'confirmada' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_citas_ginecologia`
--
DROP TABLE IF EXISTS `vista_citas_ginecologia`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_citas_ginecologia`  AS SELECT `c`.`ID_Cita` AS `ID_Cita`, `c`.`ID_Paciente` AS `ID_Paciente`, `c`.`ID_Medico` AS `ID_Medico`, `c`.`Fecha_Cita` AS `Fecha_Cita`, `c`.`Hora_Cita` AS `Hora_Cita`, `c`.`Motivo_Cita` AS `Motivo_Cita`, `c`.`Estado_Cita` AS `Estado_Cita`, `m`.`Nombre` AS `Nombre_Medico`, `m`.`Apellidos` AS `Apellido_Medico` FROM (`citas` `c` join `medicos` `m` on(`c`.`ID_Medico` = `m`.`ID_Medico`)) WHERE `m`.`Especialidad` = 'Ginecología' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_citas_manana`
--
DROP TABLE IF EXISTS `vista_citas_manana`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_citas_manana`  AS SELECT `citas`.`ID_Cita` AS `ID_Cita`, `citas`.`ID_Paciente` AS `ID_Paciente`, `citas`.`ID_Medico` AS `ID_Medico`, `citas`.`Fecha_Cita` AS `Fecha_Cita`, `citas`.`Hora_Cita` AS `Hora_Cita`, `citas`.`Motivo_Cita` AS `Motivo_Cita`, `citas`.`Estado_Cita` AS `Estado_Cita` FROM `citas` WHERE hour(`citas`.`Hora_Cita`) < 12 ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_citas_medicas_generales`
--
DROP TABLE IF EXISTS `vista_citas_medicas_generales`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_citas_medicas_generales`  AS SELECT `citas`.`ID_Cita` AS `ID_Cita`, `citas`.`ID_Paciente` AS `ID_Paciente`, `citas`.`ID_Medico` AS `ID_Medico`, `citas`.`Fecha_Cita` AS `Fecha_Cita`, `citas`.`Hora_Cita` AS `Hora_Cita`, `citas`.`Motivo_Cita` AS `Motivo_Cita`, `citas`.`Estado_Cita` AS `Estado_Cita` FROM `citas` WHERE `citas`.`Motivo_Cita` like '%Consulta médica general%' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_citas_medicos_a`
--
DROP TABLE IF EXISTS `vista_citas_medicos_a`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_citas_medicos_a`  AS SELECT `c`.`ID_Cita` AS `ID_Cita`, `c`.`ID_Paciente` AS `ID_Paciente`, `c`.`ID_Medico` AS `ID_Medico`, `c`.`Fecha_Cita` AS `Fecha_Cita`, `c`.`Hora_Cita` AS `Hora_Cita`, `c`.`Motivo_Cita` AS `Motivo_Cita`, `c`.`Estado_Cita` AS `Estado_Cita`, `m`.`Nombre` AS `Nombre_Medico`, `m`.`Apellidos` AS `Apellido_Medico` FROM (`citas` `c` join `medicos` `m` on(`c`.`ID_Medico` = `m`.`ID_Medico`)) WHERE `m`.`Nombre` like 'A%' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_citas_oftalmologia`
--
DROP TABLE IF EXISTS `vista_citas_oftalmologia`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_citas_oftalmologia`  AS SELECT `c`.`ID_Cita` AS `ID_Cita`, `c`.`ID_Paciente` AS `ID_Paciente`, `c`.`ID_Medico` AS `ID_Medico`, `c`.`Fecha_Cita` AS `Fecha_Cita`, `c`.`Hora_Cita` AS `Hora_Cita`, `c`.`Motivo_Cita` AS `Motivo_Cita`, `c`.`Estado_Cita` AS `Estado_Cita`, `m`.`Nombre` AS `Nombre_Medico`, `m`.`Especialidad` AS `Especialidad` FROM (`citas` `c` join `medicos` `m` on(`c`.`ID_Medico` = `m`.`ID_Medico`)) WHERE `m`.`Especialidad` = 'Oftalmología' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_citas_pacientes_apellido_z`
--
DROP TABLE IF EXISTS `vista_citas_pacientes_apellido_z`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_citas_pacientes_apellido_z`  AS SELECT `c`.`ID_Cita` AS `ID_Cita`, `c`.`ID_Paciente` AS `ID_Paciente`, `c`.`ID_Medico` AS `ID_Medico`, `c`.`Fecha_Cita` AS `Fecha_Cita`, `c`.`Hora_Cita` AS `Hora_Cita`, `c`.`Motivo_Cita` AS `Motivo_Cita`, `c`.`Estado_Cita` AS `Estado_Cita`, `p`.`Nombre` AS `Nombre_Paciente`, `p`.`Apellido` AS `Apellido_Paciente` FROM (`citas` `c` join `pacientes` `p` on(`c`.`ID_Paciente` = `p`.`ID_Paciente`)) WHERE `p`.`Apellido` like '%z' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_citas_pacientes_mayores`
--
DROP TABLE IF EXISTS `vista_citas_pacientes_mayores`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_citas_pacientes_mayores`  AS SELECT `c`.`ID_Cita` AS `ID_Cita`, `c`.`ID_Paciente` AS `ID_Paciente`, `c`.`ID_Medico` AS `ID_Medico`, `c`.`Fecha_Cita` AS `Fecha_Cita`, `c`.`Hora_Cita` AS `Hora_Cita`, `c`.`Motivo_Cita` AS `Motivo_Cita`, `c`.`Estado_Cita` AS `Estado_Cita`, `p`.`Nombre` AS `Nombre_Paciente`, `p`.`Apellido` AS `Apellido_Paciente`, timestampdiff(YEAR,`p`.`Fecha_Nacimiento`,curdate()) AS `Edad` FROM (`citas` `c` join `pacientes` `p` on(`c`.`ID_Paciente` = `p`.`ID_Paciente`)) WHERE timestampdiff(YEAR,`p`.`Fecha_Nacimiento`,curdate()) > 60 ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_citas_pacientes_rh_negativo`
--
DROP TABLE IF EXISTS `vista_citas_pacientes_rh_negativo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_citas_pacientes_rh_negativo`  AS SELECT `c`.`ID_Cita` AS `ID_Cita`, `c`.`ID_Paciente` AS `ID_Paciente`, `c`.`ID_Medico` AS `ID_Medico`, `c`.`Fecha_Cita` AS `Fecha_Cita`, `c`.`Hora_Cita` AS `Hora_Cita`, `c`.`Motivo_Cita` AS `Motivo_Cita`, `c`.`Estado_Cita` AS `Estado_Cita`, `p`.`Nombre` AS `Nombre_Paciente`, `p`.`tipo_sangre` AS `tipo_sangre` FROM (`citas` `c` join `pacientes` `p` on(`c`.`ID_Paciente` = `p`.`ID_Paciente`)) WHERE `p`.`tipo_sangre` like '%-' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_citas_pendientes`
--
DROP TABLE IF EXISTS `vista_citas_pendientes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_citas_pendientes`  AS SELECT `citas`.`ID_Cita` AS `ID_Cita`, `citas`.`ID_Paciente` AS `ID_Paciente`, `citas`.`ID_Medico` AS `ID_Medico`, `citas`.`Fecha_Cita` AS `Fecha_Cita`, `citas`.`Hora_Cita` AS `Hora_Cita`, `citas`.`Motivo_Cita` AS `Motivo_Cita`, `citas`.`Estado_Cita` AS `Estado_Cita` FROM `citas` WHERE `citas`.`Estado_Cita` = 'Pendiente' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_citas_proxima_semana`
--
DROP TABLE IF EXISTS `vista_citas_proxima_semana`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_citas_proxima_semana`  AS SELECT `citas`.`ID_Cita` AS `ID_Cita`, `citas`.`ID_Paciente` AS `ID_Paciente`, `citas`.`ID_Medico` AS `ID_Medico`, `citas`.`Fecha_Cita` AS `Fecha_Cita`, `citas`.`Hora_Cita` AS `Hora_Cita`, `citas`.`Motivo_Cita` AS `Motivo_Cita`, `citas`.`Estado_Cita` AS `Estado_Cita` FROM `citas` WHERE `citas`.`Fecha_Cita` between curdate() and curdate() + interval 7 day ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_citas_psiquiatria`
--
DROP TABLE IF EXISTS `vista_citas_psiquiatria`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_citas_psiquiatria`  AS SELECT `c`.`ID_Cita` AS `ID_Cita`, `c`.`ID_Paciente` AS `ID_Paciente`, `c`.`ID_Medico` AS `ID_Medico`, `c`.`Fecha_Cita` AS `Fecha_Cita`, `c`.`Hora_Cita` AS `Hora_Cita`, `c`.`Motivo_Cita` AS `Motivo_Cita`, `c`.`Estado_Cita` AS `Estado_Cita`, `m`.`Nombre` AS `Nombre_Medico`, `m`.`Apellidos` AS `Apellido_Medico` FROM (`citas` `c` join `medicos` `m` on(`c`.`ID_Medico` = `m`.`ID_Medico`)) WHERE `m`.`Especialidad` = 'Psiquiatría' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_distribucion_horarios`
--
DROP TABLE IF EXISTS `vista_distribucion_horarios`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_distribucion_horarios`  AS SELECT `horarios_medicos`.`Día` AS `Día`, count(0) AS `Total` FROM `horarios_medicos` GROUP BY `horarios_medicos`.`Día` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_habitaciones_asignadas`
--
DROP TABLE IF EXISTS `vista_habitaciones_asignadas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_habitaciones_asignadas`  AS SELECT `h`.`ID_Habitacion` AS `ID_Habitacion`, `h`.`ID_Paciente` AS `ID_Paciente`, `h`.`Numero_Habitacion` AS `Numero_Habitacion`, `h`.`Tipo_Habitacion` AS `Tipo_Habitacion`, `h`.`Estado_Habitacion` AS `Estado_Habitacion`, `h`.`Costo_Habitacion` AS `Costo_Habitacion`, `p`.`Nombre` AS `Nombre_Paciente`, `p`.`Apellido` AS `Apellido_Paciente` FROM (`habitaciones` `h` join `pacientes` `p` on(`h`.`ID_Paciente` = `p`.`ID_Paciente`)) WHERE `h`.`Estado_Habitacion` = 'Ocupada' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_habitaciones_baratas`
--
DROP TABLE IF EXISTS `vista_habitaciones_baratas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_habitaciones_baratas`  AS SELECT `habitaciones`.`ID_Habitacion` AS `ID_Habitacion`, `habitaciones`.`ID_Paciente` AS `ID_Paciente`, `habitaciones`.`Numero_Habitacion` AS `Numero_Habitacion`, `habitaciones`.`Tipo_Habitacion` AS `Tipo_Habitacion`, `habitaciones`.`Estado_Habitacion` AS `Estado_Habitacion`, `habitaciones`.`Costo_Habitacion` AS `Costo_Habitacion` FROM `habitaciones` WHERE `habitaciones`.`Costo_Habitacion` < 200000 ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_habitaciones_costosas`
--
DROP TABLE IF EXISTS `vista_habitaciones_costosas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_habitaciones_costosas`  AS SELECT `habitaciones`.`ID_Habitacion` AS `ID_Habitacion`, `habitaciones`.`ID_Paciente` AS `ID_Paciente`, `habitaciones`.`Numero_Habitacion` AS `Numero_Habitacion`, `habitaciones`.`Tipo_Habitacion` AS `Tipo_Habitacion`, `habitaciones`.`Estado_Habitacion` AS `Estado_Habitacion`, `habitaciones`.`Costo_Habitacion` AS `Costo_Habitacion` FROM `habitaciones` WHERE `habitaciones`.`Costo_Habitacion` > 500000 ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_habitaciones_disponibles`
--
DROP TABLE IF EXISTS `vista_habitaciones_disponibles`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_habitaciones_disponibles`  AS SELECT `habitaciones`.`ID_Habitacion` AS `ID_Habitacion`, `habitaciones`.`ID_Paciente` AS `ID_Paciente`, `habitaciones`.`Numero_Habitacion` AS `Numero_Habitacion`, `habitaciones`.`Tipo_Habitacion` AS `Tipo_Habitacion`, `habitaciones`.`Estado_Habitacion` AS `Estado_Habitacion`, `habitaciones`.`Costo_Habitacion` AS `Costo_Habitacion` FROM `habitaciones` WHERE `habitaciones`.`Estado_Habitacion` = 'Disponible' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_habitaciones_disponibles_economicas`
--
DROP TABLE IF EXISTS `vista_habitaciones_disponibles_economicas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_habitaciones_disponibles_economicas`  AS SELECT `habitaciones`.`ID_Habitacion` AS `ID_Habitacion`, `habitaciones`.`ID_Paciente` AS `ID_Paciente`, `habitaciones`.`Numero_Habitacion` AS `Numero_Habitacion`, `habitaciones`.`Tipo_Habitacion` AS `Tipo_Habitacion`, `habitaciones`.`Estado_Habitacion` AS `Estado_Habitacion`, `habitaciones`.`Costo_Habitacion` AS `Costo_Habitacion` FROM `habitaciones` WHERE `habitaciones`.`Estado_Habitacion` = 'Disponible' ORDER BY `habitaciones`.`Costo_Habitacion` ASC ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_habitaciones_ocupadas`
--
DROP TABLE IF EXISTS `vista_habitaciones_ocupadas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_habitaciones_ocupadas`  AS SELECT `habitaciones`.`ID_Habitacion` AS `ID_Habitacion`, `habitaciones`.`ID_Paciente` AS `ID_Paciente`, `habitaciones`.`Numero_Habitacion` AS `Numero_Habitacion`, `habitaciones`.`Tipo_Habitacion` AS `Tipo_Habitacion`, `habitaciones`.`Estado_Habitacion` AS `Estado_Habitacion`, `habitaciones`.`Costo_Habitacion` AS `Costo_Habitacion` FROM `habitaciones` WHERE `habitaciones`.`Estado_Habitacion` = 'Ocupada' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_habitaciones_pacientes_frecuentes`
--
DROP TABLE IF EXISTS `vista_habitaciones_pacientes_frecuentes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_habitaciones_pacientes_frecuentes`  AS SELECT `h`.`ID_Habitacion` AS `ID_Habitacion`, `h`.`ID_Paciente` AS `ID_Paciente`, `h`.`Numero_Habitacion` AS `Numero_Habitacion`, `h`.`Tipo_Habitacion` AS `Tipo_Habitacion`, `h`.`Estado_Habitacion` AS `Estado_Habitacion`, `h`.`Costo_Habitacion` AS `Costo_Habitacion`, `p`.`Nombre` AS `Nombre_Paciente`, `p`.`Apellido` AS `Apellido_Paciente`, count(`hc`.`ID_Historial`) AS `Total_Hospitalizaciones` FROM ((`habitaciones` `h` join `pacientes` `p` on(`h`.`ID_Paciente` = `p`.`ID_Paciente`)) join `historial_clinico` `hc` on(`p`.`ID_Paciente` = `hc`.`ID_Paciente`)) GROUP BY `h`.`ID_Habitacion` HAVING count(`hc`.`ID_Historial`) > 3 ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_habitaciones_suite`
--
DROP TABLE IF EXISTS `vista_habitaciones_suite`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_habitaciones_suite`  AS SELECT `habitaciones`.`ID_Habitacion` AS `ID_Habitacion`, `habitaciones`.`ID_Paciente` AS `ID_Paciente`, `habitaciones`.`Numero_Habitacion` AS `Numero_Habitacion`, `habitaciones`.`Tipo_Habitacion` AS `Tipo_Habitacion`, `habitaciones`.`Estado_Habitacion` AS `Estado_Habitacion`, `habitaciones`.`Costo_Habitacion` AS `Costo_Habitacion` FROM `habitaciones` WHERE `habitaciones`.`Tipo_Habitacion` = 'Suite' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_historiales_descripciones_largas`
--
DROP TABLE IF EXISTS `vista_historiales_descripciones_largas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_historiales_descripciones_largas`  AS SELECT `historial_clinico`.`ID_Historial` AS `ID_Historial`, `historial_clinico`.`ID_Paciente` AS `ID_Paciente`, `historial_clinico`.`Fecha_Historial` AS `Fecha_Historial`, `historial_clinico`.`Descripción_Historial` AS `Descripción_Historial` FROM `historial_clinico` WHERE char_length(`historial_clinico`.`Descripción_Historial`) > 100 ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_historiales_por_paciente`
--
DROP TABLE IF EXISTS `vista_historiales_por_paciente`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_historiales_por_paciente`  AS SELECT `h`.`ID_Historial` AS `ID_Historial`, `h`.`ID_Paciente` AS `ID_Paciente`, `h`.`Fecha_Historial` AS `Fecha_Historial`, `h`.`Descripción_Historial` AS `Descripción_Historial`, `p`.`Nombre` AS `Nombre`, `p`.`Apellido` AS `Apellido` FROM (`historial_clinico` `h` join `pacientes` `p` on(`h`.`ID_Paciente` = `p`.`ID_Paciente`)) ORDER BY `h`.`ID_Paciente` ASC, `h`.`Fecha_Historial` DESC ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_historiales_recientes`
--
DROP TABLE IF EXISTS `vista_historiales_recientes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_historiales_recientes`  AS SELECT `historial_clinico`.`ID_Historial` AS `ID_Historial`, `historial_clinico`.`ID_Paciente` AS `ID_Paciente`, `historial_clinico`.`Fecha_Historial` AS `Fecha_Historial`, `historial_clinico`.`Descripción_Historial` AS `Descripción_Historial` FROM `historial_clinico` WHERE `historial_clinico`.`Fecha_Historial` >= curdate() - interval 6 month ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_horarios_8am`
--
DROP TABLE IF EXISTS `vista_horarios_8am`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_horarios_8am`  AS SELECT `hm`.`ID_Horario` AS `ID_Horario`, `hm`.`ID_Medico` AS `ID_Medico`, `hm`.`Día` AS `Día`, `hm`.`Hora_Inicio` AS `Hora_Inicio`, `hm`.`Hora_Fin` AS `Hora_Fin`, `hm`.`Disponibilidad` AS `Disponibilidad`, `m`.`Nombre` AS `Nombre`, `m`.`Apellidos` AS `Apellidos` FROM (`horarios_medicos` `hm` join `medicos` `m` on(`hm`.`ID_Medico` = `m`.`ID_Medico`)) WHERE `hm`.`Hora_Inicio` = '08:00:00' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_horarios_cardiologia`
--
DROP TABLE IF EXISTS `vista_horarios_cardiologia`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_horarios_cardiologia`  AS SELECT `hm`.`ID_Horario` AS `ID_Horario`, `hm`.`ID_Medico` AS `ID_Medico`, `hm`.`Día` AS `Día`, `hm`.`Hora_Inicio` AS `Hora_Inicio`, `hm`.`Hora_Fin` AS `Hora_Fin`, `hm`.`Disponibilidad` AS `Disponibilidad`, `m`.`Nombre` AS `Nombre`, `m`.`Apellidos` AS `Apellidos` FROM (`horarios_medicos` `hm` join `medicos` `m` on(`hm`.`ID_Medico` = `m`.`ID_Medico`)) WHERE `m`.`Especialidad` = 'Cardiología' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_horarios_con_especialidad`
--
DROP TABLE IF EXISTS `vista_horarios_con_especialidad`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_horarios_con_especialidad`  AS SELECT `hm`.`ID_Horario` AS `ID_Horario`, `hm`.`ID_Medico` AS `ID_Medico`, `hm`.`Día` AS `Día`, `hm`.`Hora_Inicio` AS `Hora_Inicio`, `hm`.`Hora_Fin` AS `Hora_Fin`, `hm`.`Disponibilidad` AS `Disponibilidad`, `m`.`Nombre` AS `Nombre`, `m`.`Apellidos` AS `Apellidos`, `m`.`Especialidad` AS `Especialidad` FROM (`horarios_medicos` `hm` join `medicos` `m` on(`hm`.`ID_Medico` = `m`.`ID_Medico`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_horarios_cortos`
--
DROP TABLE IF EXISTS `vista_horarios_cortos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_horarios_cortos`  AS SELECT `horarios_medicos`.`ID_Horario` AS `ID_Horario`, `horarios_medicos`.`ID_Medico` AS `ID_Medico`, `horarios_medicos`.`Día` AS `Día`, `horarios_medicos`.`Hora_Inicio` AS `Hora_Inicio`, `horarios_medicos`.`Hora_Fin` AS `Hora_Fin`, `horarios_medicos`.`Disponibilidad` AS `Disponibilidad`, timediff(`horarios_medicos`.`Hora_Fin`,`horarios_medicos`.`Hora_Inicio`) AS `Duracion` FROM `horarios_medicos` WHERE timediff(`horarios_medicos`.`Hora_Fin`,`horarios_medicos`.`Hora_Inicio`) < '04:00:00' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_horarios_disponibles`
--
DROP TABLE IF EXISTS `vista_horarios_disponibles`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_horarios_disponibles`  AS SELECT `horarios_medicos`.`ID_Horario` AS `ID_Horario`, `horarios_medicos`.`ID_Medico` AS `ID_Medico`, `horarios_medicos`.`Día` AS `Día`, `horarios_medicos`.`Hora_Inicio` AS `Hora_Inicio`, `horarios_medicos`.`Hora_Fin` AS `Hora_Fin`, `horarios_medicos`.`Disponibilidad` AS `Disponibilidad` FROM `horarios_medicos` WHERE `horarios_medicos`.`Disponibilidad` = 'Disponible' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_horarios_disponibles_martes`
--
DROP TABLE IF EXISTS `vista_horarios_disponibles_martes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_horarios_disponibles_martes`  AS SELECT `hm`.`ID_Horario` AS `ID_Horario`, `hm`.`ID_Medico` AS `ID_Medico`, `hm`.`Día` AS `Día`, `hm`.`Hora_Inicio` AS `Hora_Inicio`, `hm`.`Hora_Fin` AS `Hora_Fin`, `hm`.`Disponibilidad` AS `Disponibilidad`, `m`.`Nombre` AS `Nombre`, `m`.`Apellidos` AS `Apellidos` FROM (`horarios_medicos` `hm` join `medicos` `m` on(`hm`.`ID_Medico` = `m`.`ID_Medico`)) WHERE `hm`.`Día` = 'Martes' AND `hm`.`Disponibilidad` = 'Disponible' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_horarios_fines_de_semana`
--
DROP TABLE IF EXISTS `vista_horarios_fines_de_semana`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_horarios_fines_de_semana`  AS SELECT `horarios_medicos`.`ID_Horario` AS `ID_Horario`, `horarios_medicos`.`ID_Medico` AS `ID_Medico`, `horarios_medicos`.`Día` AS `Día`, `horarios_medicos`.`Hora_Inicio` AS `Hora_Inicio`, `horarios_medicos`.`Hora_Fin` AS `Hora_Fin`, `horarios_medicos`.`Disponibilidad` AS `Disponibilidad` FROM `horarios_medicos` WHERE `horarios_medicos`.`Día` in ('Sábado','Domingo') ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_horarios_intermedios`
--
DROP TABLE IF EXISTS `vista_horarios_intermedios`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_horarios_intermedios`  AS SELECT `horarios_medicos`.`ID_Horario` AS `ID_Horario`, `horarios_medicos`.`ID_Medico` AS `ID_Medico`, `horarios_medicos`.`Día` AS `Día`, `horarios_medicos`.`Hora_Inicio` AS `Hora_Inicio`, `horarios_medicos`.`Hora_Fin` AS `Hora_Fin`, `horarios_medicos`.`Disponibilidad` AS `Disponibilidad` FROM `horarios_medicos` WHERE `horarios_medicos`.`Hora_Inicio` between '10:00:00' and '14:00:00' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_horarios_jornada_completa`
--
DROP TABLE IF EXISTS `vista_horarios_jornada_completa`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_horarios_jornada_completa`  AS SELECT `horarios_medicos`.`ID_Horario` AS `ID_Horario`, `horarios_medicos`.`ID_Medico` AS `ID_Medico`, `horarios_medicos`.`Día` AS `Día`, `horarios_medicos`.`Hora_Inicio` AS `Hora_Inicio`, `horarios_medicos`.`Hora_Fin` AS `Hora_Fin`, `horarios_medicos`.`Disponibilidad` AS `Disponibilidad`, timediff(`horarios_medicos`.`Hora_Fin`,`horarios_medicos`.`Hora_Inicio`) AS `Duracion` FROM `horarios_medicos` WHERE timediff(`horarios_medicos`.`Hora_Fin`,`horarios_medicos`.`Hora_Inicio`) > '08:00:00' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_horarios_lunes`
--
DROP TABLE IF EXISTS `vista_horarios_lunes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_horarios_lunes`  AS SELECT `horarios_medicos`.`ID_Horario` AS `ID_Horario`, `horarios_medicos`.`ID_Medico` AS `ID_Medico`, `horarios_medicos`.`Día` AS `Día`, `horarios_medicos`.`Hora_Inicio` AS `Hora_Inicio`, `horarios_medicos`.`Hora_Fin` AS `Hora_Fin`, `horarios_medicos`.`Disponibilidad` AS `Disponibilidad` FROM `horarios_medicos` WHERE `horarios_medicos`.`Día` = 'Lunes' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_horarios_manana`
--
DROP TABLE IF EXISTS `vista_horarios_manana`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_horarios_manana`  AS SELECT `h`.`ID_Horario` AS `ID_Horario`, `h`.`ID_Medico` AS `ID_Medico`, `h`.`Día` AS `Día`, `h`.`Hora_Inicio` AS `Hora_Inicio`, `h`.`Hora_Fin` AS `Hora_Fin`, `h`.`Disponibilidad` AS `Disponibilidad`, `m`.`Nombre` AS `Nombre_Medico`, `m`.`Apellidos` AS `Apellido_Medico` FROM (`horarios_medicos` `h` join `medicos` `m` on(`h`.`ID_Medico` = `m`.`ID_Medico`)) WHERE `h`.`Hora_Inicio` < '12:00:00' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_horarios_matutinos`
--
DROP TABLE IF EXISTS `vista_horarios_matutinos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_horarios_matutinos`  AS SELECT `horarios_medicos`.`ID_Horario` AS `ID_Horario`, `horarios_medicos`.`ID_Medico` AS `ID_Medico`, `horarios_medicos`.`Día` AS `Día`, `horarios_medicos`.`Hora_Inicio` AS `Hora_Inicio`, `horarios_medicos`.`Hora_Fin` AS `Hora_Fin`, `horarios_medicos`.`Disponibilidad` AS `Disponibilidad` FROM `horarios_medicos` WHERE `horarios_medicos`.`Hora_Inicio` < '12:00:00' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_horarios_medicos_experimentados`
--
DROP TABLE IF EXISTS `vista_horarios_medicos_experimentados`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_horarios_medicos_experimentados`  AS SELECT `hm`.`ID_Horario` AS `ID_Horario`, `hm`.`ID_Medico` AS `ID_Medico`, `hm`.`Día` AS `Día`, `hm`.`Hora_Inicio` AS `Hora_Inicio`, `hm`.`Hora_Fin` AS `Hora_Fin`, `hm`.`Disponibilidad` AS `Disponibilidad`, `m`.`Nombre` AS `Nombre`, `m`.`Apellidos` AS `Apellidos` FROM (`horarios_medicos` `hm` join `medicos` `m` on(`hm`.`ID_Medico` = `m`.`ID_Medico`)) WHERE `m`.`ID_Medico` <= 10 ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_horarios_medicos_nombres`
--
DROP TABLE IF EXISTS `vista_horarios_medicos_nombres`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_horarios_medicos_nombres`  AS SELECT `hm`.`ID_Horario` AS `ID_Horario`, `hm`.`ID_Medico` AS `ID_Medico`, `hm`.`Día` AS `Día`, `hm`.`Hora_Inicio` AS `Hora_Inicio`, `hm`.`Hora_Fin` AS `Hora_Fin`, `hm`.`Disponibilidad` AS `Disponibilidad`, `m`.`Nombre` AS `Nombre`, `m`.`Apellidos` AS `Apellidos`, `m`.`Especialidad` AS `Especialidad` FROM (`horarios_medicos` `hm` join `medicos` `m` on(`hm`.`ID_Medico` = `m`.`ID_Medico`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_horarios_neurologia`
--
DROP TABLE IF EXISTS `vista_horarios_neurologia`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_horarios_neurologia`  AS SELECT `hm`.`ID_Horario` AS `ID_Horario`, `hm`.`ID_Medico` AS `ID_Medico`, `hm`.`Día` AS `Día`, `hm`.`Hora_Inicio` AS `Hora_Inicio`, `hm`.`Hora_Fin` AS `Hora_Fin`, `hm`.`Disponibilidad` AS `Disponibilidad`, `m`.`Nombre` AS `Nombre`, `m`.`Apellidos` AS `Apellidos` FROM (`horarios_medicos` `hm` join `medicos` `m` on(`hm`.`ID_Medico` = `m`.`ID_Medico`)) WHERE `m`.`Especialidad` = 'Neurología' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_horarios_ocupados`
--
DROP TABLE IF EXISTS `vista_horarios_ocupados`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_horarios_ocupados`  AS SELECT `horarios_medicos`.`ID_Horario` AS `ID_Horario`, `horarios_medicos`.`ID_Medico` AS `ID_Medico`, `horarios_medicos`.`Día` AS `Día`, `horarios_medicos`.`Hora_Inicio` AS `Hora_Inicio`, `horarios_medicos`.`Hora_Fin` AS `Hora_Fin`, `horarios_medicos`.`Disponibilidad` AS `Disponibilidad` FROM `horarios_medicos` WHERE `horarios_medicos`.`Disponibilidad` = 'Ocupado' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_horarios_por_dia`
--
DROP TABLE IF EXISTS `vista_horarios_por_dia`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_horarios_por_dia`  AS SELECT `horarios_medicos`.`Día` AS `Día`, count(0) AS `Total_Horarios` FROM `horarios_medicos` GROUP BY `horarios_medicos`.`Día` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_horarios_por_especialidad`
--
DROP TABLE IF EXISTS `vista_horarios_por_especialidad`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_horarios_por_especialidad`  AS SELECT `h`.`ID_Horario` AS `ID_Horario`, `h`.`ID_Medico` AS `ID_Medico`, `h`.`Día` AS `Día`, `h`.`Hora_Inicio` AS `Hora_Inicio`, `h`.`Hora_Fin` AS `Hora_Fin`, `h`.`Disponibilidad` AS `Disponibilidad`, `m`.`Nombre` AS `Nombre_Medico`, `m`.`Apellidos` AS `Apellido_Medico`, `m`.`Especialidad` AS `Especialidad` FROM (`horarios_medicos` `h` join `medicos` `m` on(`h`.`ID_Medico` = `m`.`ID_Medico`)) ORDER BY `m`.`Especialidad` ASC ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_horarios_por_medico`
--
DROP TABLE IF EXISTS `vista_horarios_por_medico`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_horarios_por_medico`  AS SELECT `horarios_medicos`.`ID_Medico` AS `ID_Medico`, count(0) AS `Total_Horarios` FROM `horarios_medicos` GROUP BY `horarios_medicos`.`ID_Medico` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_horarios_tarde`
--
DROP TABLE IF EXISTS `vista_horarios_tarde`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_horarios_tarde`  AS SELECT `hm`.`ID_Horario` AS `ID_Horario`, `hm`.`ID_Medico` AS `ID_Medico`, `hm`.`Día` AS `Día`, `hm`.`Hora_Inicio` AS `Hora_Inicio`, `hm`.`Hora_Fin` AS `Hora_Fin`, `hm`.`Disponibilidad` AS `Disponibilidad`, `m`.`Nombre` AS `Nombre`, `m`.`Apellidos` AS `Apellidos` FROM (`horarios_medicos` `hm` join `medicos` `m` on(`hm`.`ID_Medico` = `m`.`ID_Medico`)) WHERE `hm`.`Hora_Fin` > '17:00:00' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_horarios_tardios`
--
DROP TABLE IF EXISTS `vista_horarios_tardios`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_horarios_tardios`  AS SELECT `hm`.`ID_Horario` AS `ID_Horario`, `hm`.`ID_Medico` AS `ID_Medico`, `hm`.`Día` AS `Día`, `hm`.`Hora_Inicio` AS `Hora_Inicio`, `hm`.`Hora_Fin` AS `Hora_Fin`, `hm`.`Disponibilidad` AS `Disponibilidad` FROM `horarios_medicos` AS `hm` WHERE `hm`.`Hora_Fin` = (select max(`horarios_medicos`.`Hora_Fin`) from `horarios_medicos` where `horarios_medicos`.`ID_Medico` = `hm`.`ID_Medico`) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_horarios_tempranos`
--
DROP TABLE IF EXISTS `vista_horarios_tempranos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_horarios_tempranos`  AS SELECT `hm`.`ID_Horario` AS `ID_Horario`, `hm`.`ID_Medico` AS `ID_Medico`, `hm`.`Día` AS `Día`, `hm`.`Hora_Inicio` AS `Hora_Inicio`, `hm`.`Hora_Fin` AS `Hora_Fin`, `hm`.`Disponibilidad` AS `Disponibilidad` FROM `horarios_medicos` AS `hm` WHERE `hm`.`Hora_Inicio` = (select min(`horarios_medicos`.`Hora_Inicio`) from `horarios_medicos` where `horarios_medicos`.`ID_Medico` = `hm`.`ID_Medico`) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_horarios_vespertinos`
--
DROP TABLE IF EXISTS `vista_horarios_vespertinos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_horarios_vespertinos`  AS SELECT `horarios_medicos`.`ID_Horario` AS `ID_Horario`, `horarios_medicos`.`ID_Medico` AS `ID_Medico`, `horarios_medicos`.`Día` AS `Día`, `horarios_medicos`.`Hora_Inicio` AS `Hora_Inicio`, `horarios_medicos`.`Hora_Fin` AS `Hora_Fin`, `horarios_medicos`.`Disponibilidad` AS `Disponibilidad` FROM `horarios_medicos` WHERE `horarios_medicos`.`Hora_Inicio` >= '12:00:00' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_medicos_disponibles_viernes`
--
DROP TABLE IF EXISTS `vista_medicos_disponibles_viernes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_medicos_disponibles_viernes`  AS SELECT `hm`.`ID_Horario` AS `ID_Horario`, `hm`.`ID_Medico` AS `ID_Medico`, `hm`.`Día` AS `Día`, `hm`.`Hora_Inicio` AS `Hora_Inicio`, `hm`.`Hora_Fin` AS `Hora_Fin`, `hm`.`Disponibilidad` AS `Disponibilidad`, `m`.`Nombre` AS `Nombre`, `m`.`Apellidos` AS `Apellidos` FROM (`horarios_medicos` `hm` join `medicos` `m` on(`hm`.`ID_Medico` = `m`.`ID_Medico`)) WHERE `hm`.`Día` = 'Viernes' AND `hm`.`Disponibilidad` = 'Disponible' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_medicos_horarios_continuos`
--
DROP TABLE IF EXISTS `vista_medicos_horarios_continuos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_medicos_horarios_continuos`  AS SELECT `horarios_medicos`.`ID_Medico` AS `ID_Medico`, count(0) AS `Cantidad_Horarios` FROM `horarios_medicos` GROUP BY `horarios_medicos`.`ID_Medico` HAVING count(0) >= 3 ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_medicos_mas_disponibles`
--
DROP TABLE IF EXISTS `vista_medicos_mas_disponibles`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_medicos_mas_disponibles`  AS SELECT `horarios_medicos`.`ID_Medico` AS `ID_Medico`, sum(case when `horarios_medicos`.`Disponibilidad` = 'Disponible' then 1 else 0 end) AS `Disponibles`, sum(case when `horarios_medicos`.`Disponibilidad` = 'Ocupado' then 1 else 0 end) AS `Ocupados` FROM `horarios_medicos` GROUP BY `horarios_medicos`.`ID_Medico` HAVING `Disponibles` > `Ocupados` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_medicos_mas_horarios`
--
DROP TABLE IF EXISTS `vista_medicos_mas_horarios`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_medicos_mas_horarios`  AS SELECT `horarios_medicos`.`ID_Medico` AS `ID_Medico`, count(0) AS `Total_Horarios` FROM `horarios_medicos` GROUP BY `horarios_medicos`.`ID_Medico` HAVING `Total_Horarios` > 2 ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_medicos_mas_lunes`
--
DROP TABLE IF EXISTS `vista_medicos_mas_lunes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_medicos_mas_lunes`  AS SELECT `horarios_medicos`.`ID_Medico` AS `ID_Medico`, count(0) AS `Total` FROM `horarios_medicos` WHERE `horarios_medicos`.`Día` = 'Lunes' GROUP BY `horarios_medicos`.`ID_Medico` ORDER BY count(0) DESC LIMIT 0, 5 ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_medicos_todos_los_dias`
--
DROP TABLE IF EXISTS `vista_medicos_todos_los_dias`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_medicos_todos_los_dias`  AS SELECT `horarios_medicos`.`ID_Medico` AS `ID_Medico` FROM `horarios_medicos` GROUP BY `horarios_medicos`.`ID_Medico` HAVING count(distinct `horarios_medicos`.`Día`) = 7 ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_promedio_duracion_horarios`
--
DROP TABLE IF EXISTS `vista_promedio_duracion_horarios`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_promedio_duracion_horarios`  AS SELECT `horarios_medicos`.`ID_Medico` AS `ID_Medico`, avg(timestampdiff(MINUTE,`horarios_medicos`.`Hora_Inicio`,`horarios_medicos`.`Hora_Fin`)) AS `Promedio_Minutos` FROM `horarios_medicos` GROUP BY `horarios_medicos`.`ID_Medico` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_ultima_consulta_paciente`
--
DROP TABLE IF EXISTS `vista_ultima_consulta_paciente`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_ultima_consulta_paciente`  AS SELECT `h`.`ID_Historial` AS `ID_Historial`, `h`.`ID_Paciente` AS `ID_Paciente`, `h`.`Fecha_Historial` AS `Fecha_Historial`, `h`.`Descripción_Historial` AS `Descripción_Historial` FROM `historial_clinico` AS `h` WHERE `h`.`Fecha_Historial` = (select max(`h2`.`Fecha_Historial`) from `historial_clinico` `h2` where `h2`.`ID_Paciente` = `h`.`ID_Paciente`) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_cantidad_formulas_medicamento`
--
DROP TABLE IF EXISTS `v_cantidad_formulas_medicamento`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_cantidad_formulas_medicamento`  AS SELECT `formulas_medicas`.`ID_Medicamento` AS `ID_Medicamento`, count(0) AS `Total_Prescripciones` FROM `formulas_medicas` GROUP BY `formulas_medicas`.`ID_Medicamento` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_facturas_cardiologia`
--
DROP TABLE IF EXISTS `v_facturas_cardiologia`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_facturas_cardiologia`  AS SELECT `f`.`ID_Factura` AS `ID_Factura`, `f`.`ID_Paciente` AS `ID_Paciente`, `f`.`ID_Medico` AS `ID_Medico`, `f`.`ID_Cita` AS `ID_Cita`, `f`.`Fecha_Factura` AS `Fecha_Factura`, `f`.`pago_Total` AS `pago_Total`, `f`.`Descripción` AS `Descripción`, `f`.`Metodo_Pago` AS `Metodo_Pago` FROM (`facturacion` `f` join `medicos` `m` on(`f`.`ID_Medico` = `m`.`ID_Medico`)) WHERE `m`.`Especialidad` = 'Cardiología' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_facturas_citas_canceladas`
--
DROP TABLE IF EXISTS `v_facturas_citas_canceladas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_facturas_citas_canceladas`  AS SELECT `f`.`ID_Factura` AS `ID_Factura`, `f`.`ID_Paciente` AS `ID_Paciente`, `f`.`ID_Medico` AS `ID_Medico`, `f`.`ID_Cita` AS `ID_Cita`, `f`.`Fecha_Factura` AS `Fecha_Factura`, `f`.`pago_Total` AS `pago_Total`, `f`.`Descripción` AS `Descripción`, `f`.`Metodo_Pago` AS `Metodo_Pago` FROM (`facturacion` `f` join `citas` `c` on(`f`.`ID_Cita` = `c`.`ID_Cita`)) WHERE `c`.`Estado_Cita` = 'Cancelada' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_facturas_pacientes_hombres`
--
DROP TABLE IF EXISTS `v_facturas_pacientes_hombres`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_facturas_pacientes_hombres`  AS SELECT `f`.`ID_Factura` AS `ID_Factura`, `f`.`ID_Paciente` AS `ID_Paciente`, `f`.`ID_Medico` AS `ID_Medico`, `f`.`ID_Cita` AS `ID_Cita`, `f`.`Fecha_Factura` AS `Fecha_Factura`, `f`.`pago_Total` AS `pago_Total`, `f`.`Descripción` AS `Descripción`, `f`.`Metodo_Pago` AS `Metodo_Pago` FROM (`facturacion` `f` join `pacientes` `p` on(`f`.`ID_Paciente` = `p`.`ID_Paciente`)) WHERE `p`.`Genero` = 'Masculino' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_formulas_ansiliticos`
--
DROP TABLE IF EXISTS `v_formulas_ansiliticos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_formulas_ansiliticos`  AS SELECT `formulas_medicas`.`ID_Formula` AS `ID_Formula`, `formulas_medicas`.`ID_Paciente` AS `ID_Paciente`, `formulas_medicas`.`ID_Medico` AS `ID_Medico`, `formulas_medicas`.`Fecha_Formula` AS `Fecha_Formula`, `formulas_medicas`.`Indicaciones` AS `Indicaciones`, `formulas_medicas`.`ID_Medicamento` AS `ID_Medicamento` FROM `formulas_medicas` WHERE `formulas_medicas`.`ID_Medicamento` in (11,12) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_formulas_antiinflamatorios`
--
DROP TABLE IF EXISTS `v_formulas_antiinflamatorios`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_formulas_antiinflamatorios`  AS SELECT `formulas_medicas`.`ID_Formula` AS `ID_Formula`, `formulas_medicas`.`ID_Paciente` AS `ID_Paciente`, `formulas_medicas`.`ID_Medico` AS `ID_Medico`, `formulas_medicas`.`Fecha_Formula` AS `Fecha_Formula`, `formulas_medicas`.`Indicaciones` AS `Indicaciones`, `formulas_medicas`.`ID_Medicamento` AS `ID_Medicamento` FROM `formulas_medicas` WHERE `formulas_medicas`.`ID_Medicamento` in (2,16,17,23) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_formulas_controladas`
--
DROP TABLE IF EXISTS `v_formulas_controladas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_formulas_controladas`  AS SELECT `formulas_medicas`.`ID_Formula` AS `ID_Formula`, `formulas_medicas`.`ID_Paciente` AS `ID_Paciente`, `formulas_medicas`.`ID_Medico` AS `ID_Medico`, `formulas_medicas`.`Fecha_Formula` AS `Fecha_Formula`, `formulas_medicas`.`Indicaciones` AS `Indicaciones`, `formulas_medicas`.`ID_Medicamento` AS `ID_Medicamento` FROM `formulas_medicas` WHERE `formulas_medicas`.`ID_Medicamento` in (11,12,22) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_formulas_hipertension`
--
DROP TABLE IF EXISTS `v_formulas_hipertension`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_formulas_hipertension`  AS SELECT `formulas_medicas`.`ID_Formula` AS `ID_Formula`, `formulas_medicas`.`ID_Paciente` AS `ID_Paciente`, `formulas_medicas`.`ID_Medico` AS `ID_Medico`, `formulas_medicas`.`Fecha_Formula` AS `Fecha_Formula`, `formulas_medicas`.`Indicaciones` AS `Indicaciones`, `formulas_medicas`.`ID_Medicamento` AS `ID_Medicamento` FROM `formulas_medicas` WHERE `formulas_medicas`.`ID_Medicamento` in (13,19,26) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_formulas_medicas_detalle`
--
DROP TABLE IF EXISTS `v_formulas_medicas_detalle`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_formulas_medicas_detalle`  AS SELECT `fm`.`ID_Formula` AS `ID_Formula`, `fm`.`Fecha_Formula` AS `Fecha_Formula`, `fm`.`Indicaciones` AS `Indicaciones`, `p`.`ID_Paciente` AS `ID_Paciente`, `p`.`Nombre` AS `Nombre_Paciente`, `p`.`Apellido` AS `Apellido_Paciente`, `m`.`ID_Medico` AS `ID_Medico`, `m`.`Nombre` AS `Nombre_Medico`, `m`.`Apellidos` AS `Apellido_Medico` FROM ((`formulas_medicas` `fm` join `pacientes` `p` on(`fm`.`ID_Paciente` = `p`.`ID_Paciente`)) join `medicos` `m` on(`fm`.`ID_Medico` = `m`.`ID_Medico`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_formulas_ordenadas`
--
DROP TABLE IF EXISTS `v_formulas_ordenadas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_formulas_ordenadas`  AS SELECT `formulas_medicas`.`ID_Formula` AS `ID_Formula`, `formulas_medicas`.`ID_Paciente` AS `ID_Paciente`, `formulas_medicas`.`ID_Medico` AS `ID_Medico`, `formulas_medicas`.`Fecha_Formula` AS `Fecha_Formula`, `formulas_medicas`.`Indicaciones` AS `Indicaciones`, `formulas_medicas`.`ID_Medicamento` AS `ID_Medicamento` FROM `formulas_medicas` ORDER BY `formulas_medicas`.`Fecha_Formula` DESC ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_formulas_pacientes_hombres`
--
DROP TABLE IF EXISTS `v_formulas_pacientes_hombres`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_formulas_pacientes_hombres`  AS SELECT `fm`.`ID_Formula` AS `ID_Formula`, `fm`.`Fecha_Formula` AS `Fecha_Formula`, `fm`.`Indicaciones` AS `Indicaciones`, `fm`.`ID_Medicamento` AS `ID_Medicamento`, `fm`.`ID_Medico` AS `ID_Medico`, `p`.`ID_Paciente` AS `ID_Paciente`, `p`.`Nombre` AS `Nombre_Paciente`, `p`.`Apellido` AS `Apellido_Paciente`, `p`.`Genero` AS `Genero` FROM (`formulas_medicas` `fm` join `pacientes` `p` on(`fm`.`ID_Paciente` = `p`.`ID_Paciente`)) WHERE `p`.`Genero` = 'Masculino' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_formulas_pacientes_jovenes`
--
DROP TABLE IF EXISTS `v_formulas_pacientes_jovenes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_formulas_pacientes_jovenes`  AS SELECT `fm`.`ID_Formula` AS `ID_Formula`, `fm`.`ID_Paciente` AS `ID_Paciente`, `fm`.`ID_Medico` AS `ID_Medico`, `fm`.`Fecha_Formula` AS `Fecha_Formula`, `fm`.`Indicaciones` AS `Indicaciones`, `fm`.`ID_Medicamento` AS `ID_Medicamento` FROM (`formulas_medicas` `fm` join `pacientes` `p` on(`fm`.`ID_Paciente` = `p`.`ID_Paciente`)) WHERE timestampdiff(YEAR,`p`.`Fecha_Nacimiento`,curdate()) < 30 ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_formulas_paracetamol`
--
DROP TABLE IF EXISTS `v_formulas_paracetamol`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_formulas_paracetamol`  AS SELECT `formulas_medicas`.`ID_Formula` AS `ID_Formula`, `formulas_medicas`.`ID_Paciente` AS `ID_Paciente`, `formulas_medicas`.`ID_Medico` AS `ID_Medico`, `formulas_medicas`.`Fecha_Formula` AS `Fecha_Formula`, `formulas_medicas`.`Indicaciones` AS `Indicaciones`, `formulas_medicas`.`ID_Medicamento` AS `ID_Medicamento` FROM `formulas_medicas` WHERE `formulas_medicas`.`ID_Medicamento` = 1 ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_formulas_por_eps`
--
DROP TABLE IF EXISTS `v_formulas_por_eps`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_formulas_por_eps`  AS SELECT `p`.`eps` AS `EPS`, count(0) AS `Total_Formulas` FROM (`formulas_medicas` `fm` join `pacientes` `p` on(`fm`.`ID_Paciente` = `p`.`ID_Paciente`)) GROUP BY `p`.`eps` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_formulas_por_especialidad`
--
DROP TABLE IF EXISTS `v_formulas_por_especialidad`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_formulas_por_especialidad`  AS SELECT `m`.`Especialidad` AS `Especialidad`, count(0) AS `Total_Formulas` FROM (`formulas_medicas` `fm` join `medicos` `m` on(`fm`.`ID_Medico` = `m`.`ID_Medico`)) GROUP BY `m`.`Especialidad` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_formulas_por_paciente`
--
DROP TABLE IF EXISTS `v_formulas_por_paciente`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_formulas_por_paciente`  AS SELECT `formulas_medicas`.`ID_Formula` AS `ID_Formula`, `formulas_medicas`.`ID_Paciente` AS `ID_Paciente`, `formulas_medicas`.`ID_Medico` AS `ID_Medico`, `formulas_medicas`.`Fecha_Formula` AS `Fecha_Formula`, `formulas_medicas`.`Indicaciones` AS `Indicaciones`, `formulas_medicas`.`ID_Medicamento` AS `ID_Medicamento` FROM `formulas_medicas` ORDER BY `formulas_medicas`.`ID_Paciente` ASC ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_formulas_ultima_semana`
--
DROP TABLE IF EXISTS `v_formulas_ultima_semana`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_formulas_ultima_semana`  AS SELECT `formulas_medicas`.`ID_Formula` AS `ID_Formula`, `formulas_medicas`.`ID_Paciente` AS `ID_Paciente`, `formulas_medicas`.`ID_Medico` AS `ID_Medico`, `formulas_medicas`.`Fecha_Formula` AS `Fecha_Formula`, `formulas_medicas`.`Indicaciones` AS `Indicaciones`, `formulas_medicas`.`ID_Medicamento` AS `ID_Medicamento` FROM `formulas_medicas` WHERE `formulas_medicas`.`Fecha_Formula` >= curdate() - interval 7 day ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_formulas_ultimos_6_meses`
--
DROP TABLE IF EXISTS `v_formulas_ultimos_6_meses`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_formulas_ultimos_6_meses`  AS SELECT `formulas_medicas`.`ID_Formula` AS `ID_Formula`, `formulas_medicas`.`ID_Paciente` AS `ID_Paciente`, `formulas_medicas`.`ID_Medico` AS `ID_Medico`, `formulas_medicas`.`Fecha_Formula` AS `Fecha_Formula`, `formulas_medicas`.`Indicaciones` AS `Indicaciones`, `formulas_medicas`.`ID_Medicamento` AS `ID_Medicamento` FROM `formulas_medicas` WHERE `formulas_medicas`.`Fecha_Formula` >= curdate() - interval 6 month ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_formulas_ultimo_mes`
--
DROP TABLE IF EXISTS `v_formulas_ultimo_mes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_formulas_ultimo_mes`  AS SELECT `formulas_medicas`.`ID_Formula` AS `ID_Formula`, `formulas_medicas`.`ID_Paciente` AS `ID_Paciente`, `formulas_medicas`.`ID_Medico` AS `ID_Medico`, `formulas_medicas`.`Fecha_Formula` AS `Fecha_Formula`, `formulas_medicas`.`Indicaciones` AS `Indicaciones`, `formulas_medicas`.`ID_Medicamento` AS `ID_Medicamento` FROM `formulas_medicas` WHERE `formulas_medicas`.`Fecha_Formula` >= curdate() - interval 1 month ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_medicamentos_mas_usados`
--
DROP TABLE IF EXISTS `v_medicamentos_mas_usados`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_medicamentos_mas_usados`  AS SELECT `formulas_medicas`.`ID_Medicamento` AS `ID_Medicamento`, count(0) AS `Total_Prescripciones` FROM `formulas_medicas` GROUP BY `formulas_medicas`.`ID_Medicamento` ORDER BY count(0) DESC ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_medicamentos_neurologia`
--
DROP TABLE IF EXISTS `v_medicamentos_neurologia`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_medicamentos_neurologia`  AS SELECT `fm`.`ID_Medicamento` AS `ID_Medicamento`, count(0) AS `Total_Prescripciones` FROM (`formulas_medicas` `fm` join `medicos` `m` on(`fm`.`ID_Medico` = `m`.`ID_Medico`)) WHERE `m`.`Especialidad` = 'Neurología' GROUP BY `fm`.`ID_Medicamento` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_medicamentos_unica_vez`
--
DROP TABLE IF EXISTS `v_medicamentos_unica_vez`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_medicamentos_unica_vez`  AS SELECT `formulas_medicas`.`ID_Medicamento` AS `ID_Medicamento`, count(0) AS `Total_Prescripciones` FROM `formulas_medicas` GROUP BY `formulas_medicas`.`ID_Medicamento` HAVING count(0) = 1 ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_medicos_aspirina`
--
DROP TABLE IF EXISTS `v_medicos_aspirina`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_medicos_aspirina`  AS SELECT DISTINCT `m`.`ID_Medico` AS `ID_Medico`, `m`.`Nombre` AS `Nombre`, `m`.`Apellidos` AS `Apellidos` FROM (`formulas_medicas` `fm` join `medicos` `m` on(`fm`.`ID_Medico` = `m`.`ID_Medico`)) WHERE `fm`.`ID_Medicamento` = 14 ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_medicos_cardiologia`
--
DROP TABLE IF EXISTS `v_medicos_cardiologia`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_medicos_cardiologia`  AS SELECT DISTINCT `m`.`ID_Medico` AS `ID_Medico`, `m`.`Nombre` AS `Nombre`, `m`.`Apellidos` AS `Apellidos` FROM (`formulas_medicas` `fm` join `medicos` `m` on(`fm`.`ID_Medico` = `m`.`ID_Medico`)) WHERE `m`.`Especialidad` = 'Cardiología' ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_medicos_frecuentes`
--
DROP TABLE IF EXISTS `v_medicos_frecuentes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_medicos_frecuentes`  AS SELECT `formulas_medicas`.`ID_Medico` AS `ID_Medico`, count(0) AS `Total_Formulas` FROM `formulas_medicas` WHERE `formulas_medicas`.`Fecha_Formula` >= curdate() - interval 1 month GROUP BY `formulas_medicas`.`ID_Medico` HAVING count(0) > 5 ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_medicos_mas_prescripciones`
--
DROP TABLE IF EXISTS `v_medicos_mas_prescripciones`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_medicos_mas_prescripciones`  AS SELECT `formulas_medicas`.`ID_Medico` AS `ID_Medico`, count(0) AS `Total_Formulas` FROM `formulas_medicas` GROUP BY `formulas_medicas`.`ID_Medico` HAVING count(0) > 10 ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_medicos_pacientes_recurrentes`
--
DROP TABLE IF EXISTS `v_medicos_pacientes_recurrentes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_medicos_pacientes_recurrentes`  AS SELECT `formulas_medicas`.`ID_Medico` AS `ID_Medico`, `formulas_medicas`.`ID_Paciente` AS `ID_Paciente`, count(0) AS `Veces_Atendido` FROM `formulas_medicas` GROUP BY `formulas_medicas`.`ID_Medico`, `formulas_medicas`.`ID_Paciente` HAVING count(0) > 3 ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_pacientes_antibioticos`
--
DROP TABLE IF EXISTS `v_pacientes_antibioticos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_pacientes_antibioticos`  AS SELECT DISTINCT `p`.`ID_Paciente` AS `ID_Paciente`, `p`.`Nombre` AS `Nombre`, `p`.`Apellido` AS `Apellido` FROM (`formulas_medicas` `fm` join `pacientes` `p` on(`fm`.`ID_Paciente` = `p`.`ID_Paciente`)) WHERE `fm`.`ID_Medicamento` in (3,9,18) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_pacientes_frecuentes`
--
DROP TABLE IF EXISTS `v_pacientes_frecuentes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_pacientes_frecuentes`  AS SELECT `formulas_medicas`.`ID_Paciente` AS `ID_Paciente`, count(0) AS `Total_Formulas` FROM `formulas_medicas` GROUP BY `formulas_medicas`.`ID_Paciente` HAVING count(0) > 5 ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_pacientes_frecuentes_mes`
--
DROP TABLE IF EXISTS `v_pacientes_frecuentes_mes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_pacientes_frecuentes_mes`  AS SELECT `formulas_medicas`.`ID_Paciente` AS `ID_Paciente`, count(0) AS `Total_Formulas` FROM `formulas_medicas` WHERE `formulas_medicas`.`Fecha_Formula` >= curdate() - interval 1 month GROUP BY `formulas_medicas`.`ID_Paciente` HAVING count(0) > 3 ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_pacientes_ibuprofeno`
--
DROP TABLE IF EXISTS `v_pacientes_ibuprofeno`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_pacientes_ibuprofeno`  AS SELECT DISTINCT `p`.`ID_Paciente` AS `ID_Paciente`, `p`.`Nombre` AS `Nombre`, `p`.`Apellido` AS `Apellido` FROM (`formulas_medicas` `fm` join `pacientes` `p` on(`fm`.`ID_Paciente` = `p`.`ID_Paciente`)) WHERE `fm`.`ID_Medicamento` = 2 ;

-- --------------------------------------------------------

--
-- Estructura para la vista `v_pacientes_prescripciones_repetidas`
--
DROP TABLE IF EXISTS `v_pacientes_prescripciones_repetidas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_pacientes_prescripciones_repetidas`  AS SELECT `formulas_medicas`.`ID_Paciente` AS `ID_Paciente`, `formulas_medicas`.`ID_Medicamento` AS `ID_Medicamento`, count(0) AS `Veces_Prescrito` FROM `formulas_medicas` GROUP BY `formulas_medicas`.`ID_Paciente`, `formulas_medicas`.`ID_Medicamento` HAVING count(0) > 1 ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `citas`
--
ALTER TABLE `citas`
  ADD PRIMARY KEY (`ID_Cita`),
  ADD KEY `ID_Paciente` (`ID_Paciente`),
  ADD KEY `ID_Medico` (`ID_Medico`);

--
-- Indices de la tabla `facturacion`
--
ALTER TABLE `facturacion`
  ADD PRIMARY KEY (`ID_Factura`),
  ADD KEY `ID_Paciente` (`ID_Paciente`),
  ADD KEY `ID_Medico` (`ID_Medico`),
  ADD KEY `ID_Cita` (`ID_Cita`);

--
-- Indices de la tabla `formulas_medicas`
--
ALTER TABLE `formulas_medicas`
  ADD PRIMARY KEY (`ID_Formula`),
  ADD KEY `ID_Paciente` (`ID_Paciente`),
  ADD KEY `ID_Medico` (`ID_Medico`),
  ADD KEY `formulas_medicas_ibfk_3` (`ID_Medicamento`);

--
-- Indices de la tabla `habitaciones`
--
ALTER TABLE `habitaciones`
  ADD PRIMARY KEY (`ID_Habitacion`),
  ADD KEY `ID_Paciente` (`ID_Paciente`);

--
-- Indices de la tabla `historial_clinico`
--
ALTER TABLE `historial_clinico`
  ADD PRIMARY KEY (`ID_Historial`),
  ADD KEY `ID_Paciente` (`ID_Paciente`);

--
-- Indices de la tabla `horarios_medicos`
--
ALTER TABLE `horarios_medicos`
  ADD PRIMARY KEY (`ID_Horario`),
  ADD KEY `ID_Medico` (`ID_Medico`);

--
-- Indices de la tabla `medicamentos`
--
ALTER TABLE `medicamentos`
  ADD PRIMARY KEY (`ID_Medicamento`);

--
-- Indices de la tabla `medicos`
--
ALTER TABLE `medicos`
  ADD PRIMARY KEY (`ID_Medico`);

--
-- Indices de la tabla `pacientes`
--
ALTER TABLE `pacientes`
  ADD PRIMARY KEY (`ID_Paciente`);

--
-- Indices de la tabla `tratamientos`
--
ALTER TABLE `tratamientos`
  ADD PRIMARY KEY (`ID_Tratamiento`),
  ADD KEY `tratamientos_ibfk_1` (`ID_Historial`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `citas`
--
ALTER TABLE `citas`
  MODIFY `ID_Cita` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `medicos`
--
ALTER TABLE `medicos`
  MODIFY `ID_Medico` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT de la tabla `pacientes`
--
ALTER TABLE `pacientes`
  MODIFY `ID_Paciente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `citas`
--
ALTER TABLE `citas`
  ADD CONSTRAINT `citas_ibfk_1` FOREIGN KEY (`ID_Paciente`) REFERENCES `pacientes` (`ID_Paciente`),
  ADD CONSTRAINT `citas_ibfk_2` FOREIGN KEY (`ID_Medico`) REFERENCES `medicos` (`ID_Medico`);

--
-- Filtros para la tabla `facturacion`
--
ALTER TABLE `facturacion`
  ADD CONSTRAINT `facturacion_ibfk_1` FOREIGN KEY (`ID_Paciente`) REFERENCES `pacientes` (`ID_Paciente`),
  ADD CONSTRAINT `facturacion_ibfk_2` FOREIGN KEY (`ID_Medico`) REFERENCES `medicos` (`ID_Medico`),
  ADD CONSTRAINT `facturacion_ibfk_3` FOREIGN KEY (`ID_Cita`) REFERENCES `citas` (`ID_Cita`);

--
-- Filtros para la tabla `formulas_medicas`
--
ALTER TABLE `formulas_medicas`
  ADD CONSTRAINT `formulas_medicas_ibfk_1` FOREIGN KEY (`ID_Paciente`) REFERENCES `pacientes` (`ID_Paciente`),
  ADD CONSTRAINT `formulas_medicas_ibfk_2` FOREIGN KEY (`ID_Medico`) REFERENCES `medicos` (`ID_Medico`),
  ADD CONSTRAINT `formulas_medicas_ibfk_3` FOREIGN KEY (`ID_Medicamento`) REFERENCES `medicamentos` (`ID_Medicamento`);

--
-- Filtros para la tabla `habitaciones`
--
ALTER TABLE `habitaciones`
  ADD CONSTRAINT `habitaciones_ibfk_1` FOREIGN KEY (`ID_Paciente`) REFERENCES `pacientes` (`ID_Paciente`) ON DELETE SET NULL;

--
-- Filtros para la tabla `historial_clinico`
--
ALTER TABLE `historial_clinico`
  ADD CONSTRAINT `historial_clinico_ibfk_1` FOREIGN KEY (`ID_Paciente`) REFERENCES `pacientes` (`ID_Paciente`);

--
-- Filtros para la tabla `horarios_medicos`
--
ALTER TABLE `horarios_medicos`
  ADD CONSTRAINT `horarios_medicos_ibfk_1` FOREIGN KEY (`ID_Medico`) REFERENCES `medicos` (`ID_Medico`);

--
-- Filtros para la tabla `tratamientos`
--
ALTER TABLE `tratamientos`
  ADD CONSTRAINT `tratamientos_ibfk_1` FOREIGN KEY (`ID_Historial`) REFERENCES `historial_clinico` (`ID_Historial`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

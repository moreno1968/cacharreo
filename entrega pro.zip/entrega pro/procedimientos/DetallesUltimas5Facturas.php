<?php
include 'conexion.php'; // Archivo de conexión a la base de datos

$sql = "CALL DetallesUltimas5Facturas()";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Detalles de las Últimas 5 Facturas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2 class="mb-4">Detalles de las Últimas 5 Facturas</h2>
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
        <tr>
            <th>ID Factura</th>
            <th>Nombre Cliente</th>
            <th>Apellido Cliente</th>
            <th>Producto</th>
            <th>Cantidad</th>
            <th>Precio Unitario</th>
            <th>Subtotal</th>
        </tr>
        </thead>
        <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['ID_Factura']) ?></td>
                <td><?= htmlspecialchars($row['Nombre']) ?></td>
                <td><?= htmlspecialchars($row['Apellido']) ?></td>
                <td><?= htmlspecialchars($row['Producto']) ?></td>
                <td><?= htmlspecialchars($row['Cantidad']) ?></td>
                <td><?= htmlspecialchars($row['Precio_Unitario']) ?></td>
                <td><?= htmlspecialchars($row['Subtotal']) ?></td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>
</body>
</html>

<?php
include 'conexion.php'; // Archivo de conexión a la base de datos

$sql = "CALL ObtenerProveedoresDeCarne()";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Número de Proveedores de Carne</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2 class="mb-4">Número de Proveedores de Carne</h2>
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
        <tr>
            <th>Número de Proveedores</th>
        </tr>
        </thead>
        <tbody>
        <?php if ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['NumeroDeProveedores']) ?></td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>
-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 13-03-2025 a las 05:24:12
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `supermercadojj`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `CantidadProductosPorCategori` ()   BEGIN
    SELECT cp.Nombre_Categoria, COUNT(p.ID_Producto) AS Total_Productos
    FROM Categoria_Productos cp
    LEFT JOIN Productos p ON cp.ID_Categoria = p.ID_Categoria
    GROUP BY cp.Nombre_Categoria
    ORDER BY Total_Productos DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ClientesMasCompras` ()   BEGIN
    SELECT c.ID_Cliente, c.Nombre, c.Apellido, COUNT(f.ID_Factura) AS Total_Compras
    FROM Clientes c
    JOIN Facturas f ON c.ID_Cliente = f.ID_Cliente
    GROUP BY c.ID_Cliente, c.Nombre, c.Apellido
    ORDER BY Total_Compras DESC
    LIMIT 10;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `DetallesUltimas5Facturas` ()   BEGIN
    SELECT f.ID_Factura, c.Nombre, c.Apellido, p.Nombre AS Producto, 
           df.Cantidad, df.Precio_Unitario, (df.Cantidad * df.Precio_Unitario) AS Subtotal
    FROM Facturas f
    JOIN Clientes c ON f.ID_Cliente = c.ID_Cliente
    JOIN Detalle_Factura df ON f.ID_Factura = df.ID_Factura
    JOIN Productos p ON df.ID_Producto = p.ID_Producto
    ORDER BY f.Fecha_Factura DESC
    LIMIT 5;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `HistorialUltimos5Clientes` ()   BEGIN
    SELECT f.ID_Factura, f.ID_Cliente, c.Nombre, c.Apellido, f.Fecha_Factura, f.pago_Total, f.Metodo_Pago
    FROM Facturas f
    JOIN Clientes c ON f.ID_Cliente = c.ID_Cliente
    ORDER BY f.Fecha_Factura DESC
    LIMIT 5;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenerClientesConMasDe150Puntos` ()   BEGIN
    SELECT c.ID_Cliente, c.Nombre, c.Apellido, p.Puntos_acomulados
    FROM Clientes c
    JOIN Puntos p ON c.ID_Cliente = p.ID_Cliente
    WHERE p.Puntos_acomulados > 150
    ORDER BY p.Puntos_acomulados DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenerProductosConA` ()   BEGIN
    SELECT ID_Producto, Nombre, Descripcion, Precio, Stock 
    FROM Productos 
    WHERE Nombre LIKE '%a%' OR Nombre LIKE '%A%'
    ORDER BY Nombre;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenerProveedoresDeCarne` ()   BEGIN
    SELECT COUNT(*) AS NumeroDeProveedores
    FROM proveedores
    WHERE Nombre LIKE '%Carne%';
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ProductosBajoStock` ()   BEGIN
    SELECT p.Nombre, i.Stock_Actual
    FROM Productos p
    JOIN Inventario i ON p.ID_Producto = i.ID_Producto
    WHERE i.Stock_Actual < 35
    ORDER BY i.Stock_Actual ASC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ProductosVendidos` ()   BEGIN
    SELECT p.Nombre, SUM(df.Cantidad) AS Total_Vendido
    FROM Productos p
    JOIN Detalle_Factura df ON p.ID_Producto = df.ID_Producto
    GROUP BY p.ID_Producto
    ORDER BY Total_Vendido DESC
    LIMIT 10;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ProveedoresMasCompras` ()   BEGIN
    SELECT pr.Nombre, COUNT(cp.ID_Compra_prov) AS Total_Compras
    FROM Proveedores pr
    JOIN compras_prov cp ON pr.ID_Proveedor = cp.ID_Proveedor
    GROUP BY pr.ID_Proveedor
    ORDER BY Total_Compras DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `StockPorCategoria` ()   BEGIN
    SELECT cp.Nombre_Categoria, SUM(i.Stock_Actual) AS Total_Stock
    FROM Categoria_Productos cp
    JOIN Productos p ON cp.ID_Categoria = p.ID_Categoria
    JOIN Inventario i ON p.ID_Producto = i.ID_Producto
    GROUP BY cp.Nombre_Categoria
    ORDER BY Total_Stock DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `VentasPorMetodoPago` ()   BEGIN
    SELECT Metodo_Pago, SUM(pago_Total) AS Total_Ventas
    FROM Facturas
    GROUP BY Metodo_Pago
    ORDER BY Total_Ventas DESC;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria_productos`
--

CREATE TABLE `categoria_productos` (
  `ID_Categoria` int(11) NOT NULL,
  `Nombre_Categoria` varchar(50) NOT NULL,
  `Descripcion` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `categoria_productos`
--

INSERT INTO `categoria_productos` (`ID_Categoria`, `Nombre_Categoria`, `Descripcion`) VALUES
(1, 'Lácteos', 'Productos derivados de la leche'),
(2, 'Carnes', 'Productos cárnicos frescos y procesados'),
(3, 'Bebidas', 'Jugos, gaseosas y bebidas energéticas'),
(4, 'Panadería', 'Productos horneados como pan y galletas'),
(5, 'Verduras', 'Hortalizas y vegetales frescos'),
(6, 'Frutas', 'Frutas frescas y enlatadas'),
(7, 'Abarrotes', 'Productos no perecederos como arroz y frijoles'),
(8, 'Limpieza', 'Productos de aseo personal y del hogar'),
(9, 'Bebés', 'Productos para bebés como pañales y fórmulas'),
(10, 'Mascotas', 'Alimentos y accesorios para mascotas'),
(11, 'Carnes', 'Productos como chicharon fritos, costillas y chicharron'),
(12, 'Congelados', 'Alimentos congelados como carnes, verduras y comidas preparadas'),
(13, 'Electrodomésticos', 'Pequeños electrodomésticos para el hogar como licuadoras y cafeteras');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `ID_Cliente` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Apellido` varchar(50) NOT NULL,
  `Telefono` varchar(15) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Barrio` text DEFAULT NULL,
  `Puntos` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`ID_Cliente`, `Nombre`, `Apellido`, `Telefono`, `Email`, `Barrio`, `Puntos`) VALUES
(1, 'Carlos', 'Santos', '3216549870', 'carlos.santos@email.com', 'Bogotá', 100),
(2, 'Luisa', 'Fernandez', '3125678945', 'luisa.fernandez@email.com', 'Medellín', 200),
(3, 'Fernando', 'Luna', '3159871234', 'fernando.luna@email.com', 'Cali', 150),
(4, 'Margarita', 'Rojas', '3101234567', 'margarita.rojas@email.com', 'Barranquilla', 50),
(5, 'Jorge', 'Castro', '3204567891', 'jorge.castro@email.com', 'Cartagena', 75),
(6, 'Andrea', 'Ramirez', '3198745632', 'andrea.ramirez@email.com', 'Bucaramanga', 125),
(7, 'Sebastián', 'Mendoza', '3119854321', 'sebastian.mendoza@email.com', 'Manizales', 175),
(8, 'Natalia', 'Ortega', '3227654321', 'natalia.ortega@email.com', 'Pereira', 90),
(9, 'Raúl', 'Peña', '3136789543', 'raul.pena@email.com', 'Ibagué', 120),
(10, 'Camila', 'Hernández', '3187654321', 'camila.hernandez@email.com', 'Cúcuta', 110);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compras_prov`
--

CREATE TABLE `compras_prov` (
  `ID_Compra_prov` int(11) NOT NULL,
  `ID_Proveedor` int(11) DEFAULT NULL,
  `Fecha_Compra` timestamp NOT NULL DEFAULT current_timestamp(),
  `Monto_Total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `compras_prov`
--

INSERT INTO `compras_prov` (`ID_Compra_prov`, `ID_Proveedor`, `Fecha_Compra`, `Monto_Total`) VALUES
(1, 1, '2025-03-03 14:18:56', 500.00),
(2, 2, '2025-03-03 14:18:56', 1200.00),
(3, 3, '2025-03-03 14:18:56', 300.00),
(4, 4, '2025-03-03 14:18:56', 400.00),
(5, 5, '2025-03-03 14:18:56', 700.00),
(6, 1, '2025-03-03 14:18:56', 600.00),
(7, 2, '2025-03-03 14:18:56', 1500.00),
(8, 3, '2025-03-03 14:18:56', 450.00),
(9, 4, '2025-03-03 14:18:56', 550.00),
(10, 5, '2025-03-03 14:18:56', 800.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_factura`
--

CREATE TABLE `detalle_factura` (
  `ID_Detalle` int(11) NOT NULL,
  `ID_Factura` int(11) DEFAULT NULL,
  `ID_Producto` int(11) DEFAULT NULL,
  `Cantidad` int(11) NOT NULL,
  `Precio_Unitario` decimal(10,2) NOT NULL,
  `Subtotal` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `detalle_factura`
--

INSERT INTO `detalle_factura` (`ID_Detalle`, `ID_Factura`, `ID_Producto`, `Cantidad`, `Precio_Unitario`, `Subtotal`) VALUES
(1, 1, 1, 2, 3.50, 7.00),
(2, 2, 3, 1, 2.80, 2.80),
(3, 3, 5, 4, 1.20, 4.80),
(4, 4, 7, 2, 5.50, 11.00),
(5, 5, 10, 1, 20.00, 20.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `devoluciones`
--

CREATE TABLE `devoluciones` (
  `ID_Devolucion` int(11) NOT NULL,
  `ID_Factura` int(11) DEFAULT NULL,
  `ID_Producto` int(11) DEFAULT NULL,
  `Cantidad` int(11) NOT NULL,
  `Motivo` text NOT NULL,
  `Fecha_Devolucion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleados`
--

CREATE TABLE `empleados` (
  `ID_Empleado` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Apellido` varchar(50) NOT NULL,
  `Cargo` varchar(50) NOT NULL,
  `Salario` decimal(10,2) NOT NULL,
  `Telefono` varchar(15) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `barrio` text DEFAULT NULL,
  `Fecha_Contratacion` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `facturas`
--

CREATE TABLE `facturas` (
  `ID_Factura` int(11) NOT NULL,
  `ID_Cliente` int(11) DEFAULT NULL,
  `Fecha_Factura` timestamp NOT NULL DEFAULT current_timestamp(),
  `pago_Total` decimal(10,2) NOT NULL,
  `Metodo_Pago` enum('Efectivo','Tarjeta','Transferencia','Otros') NOT NULL,
  `Puntos_acum_anterior` int(11) NOT NULL,
  `Puntos_Ganados` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `facturas`
--

INSERT INTO `facturas` (`ID_Factura`, `ID_Cliente`, `Fecha_Factura`, `pago_Total`, `Metodo_Pago`, `Puntos_acum_anterior`, `Puntos_Ganados`) VALUES
(1, 1, '2025-03-03 14:18:56', 50.00, 'Tarjeta', 100, 10),
(2, 2, '2025-03-03 14:18:56', 80.00, 'Efectivo', 200, 16),
(3, 3, '2025-03-03 14:18:56', 120.00, 'Transferencia', 150, 24),
(4, 4, '2025-03-03 14:18:56', 30.00, 'Otros', 50, 6),
(5, 5, '2025-03-03 14:18:56', 75.00, 'Tarjeta', 75, 12),
(6, 6, '2025-03-03 14:18:56', 90.00, 'Efectivo', 125, 18),
(7, 7, '2025-03-03 14:18:56', 110.00, 'Tarjeta', 175, 20),
(8, 8, '2025-03-03 14:18:56', 95.00, 'Transferencia', 90, 14),
(9, 9, '2025-03-03 14:18:56', 60.00, 'Efectivo', 120, 12),
(10, 10, '2025-03-03 14:18:56', 85.00, 'Tarjeta', 110, 15);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventario`
--

CREATE TABLE `inventario` (
  `ID_Inventario` int(11) NOT NULL,
  `ID_Producto` int(11) DEFAULT NULL,
  `Stock_actual` int(11) NOT NULL,
  `Ultima_modificacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `inventario`
--

INSERT INTO `inventario` (`ID_Inventario`, `ID_Producto`, `Stock_actual`, `Ultima_modificacion`) VALUES
(1, 1, 100, '2025-03-03 14:18:56'),
(2, 2, 50, '2025-03-03 14:18:56'),
(3, 3, 80, '2025-03-03 14:18:56'),
(4, 4, 60, '2025-03-03 14:18:56'),
(5, 5, 100, '2025-03-03 14:18:56'),
(6, 6, 70, '2025-03-03 14:18:56'),
(7, 7, 90, '2025-03-03 14:18:56'),
(8, 8, 40, '2025-03-03 14:18:56'),
(9, 9, 5, '2025-03-13 01:26:41'),
(10, 10, 9, '2025-03-13 01:26:52');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `ID_Producto` int(11) NOT NULL,
  `ID_Categoria` int(11) DEFAULT NULL,
  `Nombre` varchar(100) NOT NULL,
  `Descripcion` text DEFAULT NULL,
  `Precio` decimal(10,2) NOT NULL,
  `Stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`ID_Producto`, `ID_Categoria`, `Nombre`, `Descripcion`, `Precio`, `Stock`) VALUES
(1, 1, 'Leche Entera', 'Leche pasteurizada 1L', 3.50, 100),
(2, 2, 'Carne de Res', 'Corte de solomillo 500g', 12.00, 50),
(3, 3, 'Jugo de Naranja', 'Jugo natural 1L', 2.80, 80),
(4, 4, 'Pan Baguette', 'Pan francés 250g', 1.50, 60),
(5, 5, 'Zanahorias', 'Bolsa de zanahorias 500g', 1.20, 100),
(6, 6, 'Manzanas', 'Manzanas rojas 1kg', 3.00, 70),
(7, 7, 'Arroz Blanco', 'Paquete de 5kg', 5.50, 90),
(8, 8, 'Detergente', 'Detergente líquido 2L', 4.80, 40),
(9, 9, 'Pañales', 'Pañales talla M - 40 unidades', 10.00, 30),
(10, 10, 'Croquetas para Perro', 'Bolsa de 10kg', 20.00, 25),
(11, 11, 'chicharrones fritos Clásicos', 'Bolsa de chicharrones fritos de 150g', 2.50, 200),
(12, 12, 'Pizza Congelada', 'Pizza de pepperoni lista para hornear', 5.99, 100),
(13, 13, 'Licuadora 2L', 'Licuadora eléctrica con vaso de vidrio', 35.00, 50);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

CREATE TABLE `proveedores` (
  `ID_Proveedor` int(11) NOT NULL,
  `Nombre` varchar(100) NOT NULL,
  `Contacto` varchar(50) DEFAULT NULL,
  `Telefono` varchar(15) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`ID_Proveedor`, `Nombre`, `Contacto`, `Telefono`, `Email`) VALUES
(1, 'Lacteos S.A.', 'Juan Pérez', '3216549870', 'contacto@lacteos.com'),
(2, 'Carnes del Valle', 'Pedro Gómez', '3125678945', 'ventas@carnes.com'),
(3, 'Bebidas Express', 'Laura Ramírez', '3159871234', 'info@bebidas.com'),
(4, 'Panadería El Trigo', 'Andrés Martínez', '3101234567', 'ventas@panaderia.com'),
(5, 'Frutas Selectas', 'Marta Ortiz', '3204567891', 'info@frutas.com'),
(6, 'express Carnes', 'denzel encarnacion', '3135284962', 'express@gmail.com');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `puntos`
--

CREATE TABLE `puntos` (
  `ID_Cliente` int(11) NOT NULL,
  `Puntos_acomulados` int(11) DEFAULT 0,
  `Ultima_modificacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `puntos`
--

INSERT INTO `puntos` (`ID_Cliente`, `Puntos_acomulados`, `Ultima_modificacion`) VALUES
(1, 110, '2025-03-03 14:24:52'),
(2, 216, '2025-03-03 14:24:52'),
(3, 174, '2025-03-03 14:24:52'),
(4, 56, '2025-03-03 14:24:52'),
(5, 87, '2025-03-03 14:24:52'),
(6, 143, '2025-03-03 14:24:52'),
(7, 195, '2025-03-03 14:24:52'),
(8, 104, '2025-03-03 14:24:52'),
(9, 132, '2025-03-03 14:24:52'),
(10, 125, '2025-03-03 14:24:52');

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_clientes_fieles`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_clientes_fieles` (
`ID_Cliente` int(11)
,`Nombre` varchar(50)
,`Apellido` varchar(50)
,`barrio` text
,`Puntos` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_clientes_puntos`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_clientes_puntos` (
`ID_Cliente` int(11)
,`Nombre` varchar(50)
,`Apellido` varchar(50)
,`barrio` text
,`Puntos` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_compras_detalles`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_compras_detalles` (
`ID_Compra_prov` int(11)
,`Proveedor` varchar(100)
,`Producto` varchar(100)
,`Precio` decimal(10,2)
,`Monto_Total` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_compras_proveedores`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_compras_proveedores` (
`ID_Compra_prov` int(11)
,`Proveedor` varchar(100)
,`Monto_Total` decimal(10,2)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_facturas_clientes`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_facturas_clientes` (
`ID_Factura` int(11)
,`Nombre` varchar(50)
,`Apellido` varchar(50)
,`Fecha_Factura` timestamp
,`pago_Total` decimal(10,2)
,`Metodo_Pago` enum('Efectivo','Tarjeta','Transferencia','Otros')
,`Puntos_acum_anterior` int(11)
,`Puntos_Ganados` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_inventario_detallado`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_inventario_detallado` (
`ID_Inventario` int(11)
,`Producto` varchar(100)
,`Descripcion` text
,`Nombre_Categoria` varchar(50)
,`Stock_Actual` int(11)
,`Valor_Total` decimal(20,2)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_inventario_productos`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_inventario_productos` (
`ID_Inventario` int(11)
,`Producto` varchar(100)
,`Stock_Actual` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_productos_bajo_stock`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_productos_bajo_stock` (
`ID_Producto` int(11)
,`Nombre` varchar(100)
,`Stock` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_productos_categoria`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_productos_categoria` (
`ID_Producto` int(11)
,`Producto` varchar(100)
,`Precio` decimal(10,2)
,`Stock` int(11)
,`Nombre_Categoria` varchar(50)
);

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_clientes_fieles`
--
DROP TABLE IF EXISTS `vista_clientes_fieles`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_clientes_fieles`  AS SELECT `clientes`.`ID_Cliente` AS `ID_Cliente`, `clientes`.`Nombre` AS `Nombre`, `clientes`.`Apellido` AS `Apellido`, `clientes`.`Barrio` AS `barrio`, `clientes`.`Puntos` AS `Puntos` FROM `clientes` WHERE `clientes`.`Puntos` > 100 ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_clientes_puntos`
--
DROP TABLE IF EXISTS `vista_clientes_puntos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_clientes_puntos`  AS SELECT `clientes`.`ID_Cliente` AS `ID_Cliente`, `clientes`.`Nombre` AS `Nombre`, `clientes`.`Apellido` AS `Apellido`, `clientes`.`Barrio` AS `barrio`, `clientes`.`Puntos` AS `Puntos` FROM `clientes` ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_compras_detalles`
--
DROP TABLE IF EXISTS `vista_compras_detalles`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_compras_detalles`  AS SELECT `cp`.`ID_Compra_prov` AS `ID_Compra_prov`, `p`.`Nombre` AS `Proveedor`, `pr`.`Nombre` AS `Producto`, `pr`.`Precio` AS `Precio`, `cp`.`Monto_Total` AS `Monto_Total` FROM ((`compras_prov` `cp` join `proveedores` `p` on(`cp`.`ID_Proveedor` = `p`.`ID_Proveedor`)) join `productos` `pr` on(`pr`.`ID_Categoria` = (select `productos`.`ID_Categoria` from `productos` where `productos`.`ID_Producto` = `pr`.`ID_Producto` limit 1))) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_compras_proveedores`
--
DROP TABLE IF EXISTS `vista_compras_proveedores`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_compras_proveedores`  AS SELECT `cp`.`ID_Compra_prov` AS `ID_Compra_prov`, `p`.`Nombre` AS `Proveedor`, `cp`.`Monto_Total` AS `Monto_Total` FROM (`compras_prov` `cp` join `proveedores` `p` on(`cp`.`ID_Proveedor` = `p`.`ID_Proveedor`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_facturas_clientes`
--
DROP TABLE IF EXISTS `vista_facturas_clientes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_facturas_clientes`  AS SELECT `f`.`ID_Factura` AS `ID_Factura`, `c`.`Nombre` AS `Nombre`, `c`.`Apellido` AS `Apellido`, `f`.`Fecha_Factura` AS `Fecha_Factura`, `f`.`pago_Total` AS `pago_Total`, `f`.`Metodo_Pago` AS `Metodo_Pago`, `f`.`Puntos_acum_anterior` AS `Puntos_acum_anterior`, `f`.`Puntos_Ganados` AS `Puntos_Ganados` FROM (`facturas` `f` join `clientes` `c` on(`f`.`ID_Cliente` = `c`.`ID_Cliente`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_inventario_detallado`
--
DROP TABLE IF EXISTS `vista_inventario_detallado`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_inventario_detallado`  AS SELECT `i`.`ID_Inventario` AS `ID_Inventario`, `p`.`Nombre` AS `Producto`, `p`.`Descripcion` AS `Descripcion`, `c`.`Nombre_Categoria` AS `Nombre_Categoria`, `i`.`Stock_actual` AS `Stock_Actual`, `i`.`Stock_actual`* `p`.`Precio` AS `Valor_Total` FROM ((`inventario` `i` join `productos` `p` on(`i`.`ID_Producto` = `p`.`ID_Producto`)) join `categoria_productos` `c` on(`p`.`ID_Categoria` = `c`.`ID_Categoria`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_inventario_productos`
--
DROP TABLE IF EXISTS `vista_inventario_productos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_inventario_productos`  AS SELECT `i`.`ID_Inventario` AS `ID_Inventario`, `p`.`Nombre` AS `Producto`, `i`.`Stock_actual` AS `Stock_Actual` FROM (`inventario` `i` join `productos` `p` on(`i`.`ID_Producto` = `p`.`ID_Producto`)) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_productos_bajo_stock`
--
DROP TABLE IF EXISTS `vista_productos_bajo_stock`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_productos_bajo_stock`  AS SELECT `productos`.`ID_Producto` AS `ID_Producto`, `productos`.`Nombre` AS `Nombre`, `productos`.`Stock` AS `Stock` FROM `productos` WHERE `productos`.`Stock` < 50 ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_productos_categoria`
--
DROP TABLE IF EXISTS `vista_productos_categoria`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_productos_categoria`  AS SELECT `p`.`ID_Producto` AS `ID_Producto`, `p`.`Nombre` AS `Producto`, `p`.`Precio` AS `Precio`, `p`.`Stock` AS `Stock`, `c`.`Nombre_Categoria` AS `Nombre_Categoria` FROM (`productos` `p` join `categoria_productos` `c` on(`p`.`ID_Categoria` = `c`.`ID_Categoria`)) ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categoria_productos`
--
ALTER TABLE `categoria_productos`
  ADD PRIMARY KEY (`ID_Categoria`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`ID_Cliente`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indices de la tabla `compras_prov`
--
ALTER TABLE `compras_prov`
  ADD PRIMARY KEY (`ID_Compra_prov`),
  ADD KEY `ID_Proveedor` (`ID_Proveedor`);

--
-- Indices de la tabla `detalle_factura`
--
ALTER TABLE `detalle_factura`
  ADD PRIMARY KEY (`ID_Detalle`),
  ADD KEY `ID_Factura` (`ID_Factura`),
  ADD KEY `ID_Producto` (`ID_Producto`);

--
-- Indices de la tabla `devoluciones`
--
ALTER TABLE `devoluciones`
  ADD PRIMARY KEY (`ID_Devolucion`),
  ADD KEY `ID_Factura` (`ID_Factura`),
  ADD KEY `ID_Producto` (`ID_Producto`);

--
-- Indices de la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD PRIMARY KEY (`ID_Empleado`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indices de la tabla `facturas`
--
ALTER TABLE `facturas`
  ADD PRIMARY KEY (`ID_Factura`),
  ADD KEY `ID_Cliente` (`ID_Cliente`);

--
-- Indices de la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD PRIMARY KEY (`ID_Inventario`),
  ADD KEY `ID_Producto` (`ID_Producto`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`ID_Producto`),
  ADD KEY `ID_Categoria` (`ID_Categoria`);

--
-- Indices de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  ADD PRIMARY KEY (`ID_Proveedor`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indices de la tabla `puntos`
--
ALTER TABLE `puntos`
  ADD PRIMARY KEY (`ID_Cliente`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categoria_productos`
--
ALTER TABLE `categoria_productos`
  MODIFY `ID_Categoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `ID_Cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `compras_prov`
--
ALTER TABLE `compras_prov`
  MODIFY `ID_Compra_prov` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `detalle_factura`
--
ALTER TABLE `detalle_factura`
  MODIFY `ID_Detalle` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `devoluciones`
--
ALTER TABLE `devoluciones`
  MODIFY `ID_Devolucion` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `empleados`
--
ALTER TABLE `empleados`
  MODIFY `ID_Empleado` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `facturas`
--
ALTER TABLE `facturas`
  MODIFY `ID_Factura` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `inventario`
--
ALTER TABLE `inventario`
  MODIFY `ID_Inventario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `ID_Producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  MODIFY `ID_Proveedor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `compras_prov`
--
ALTER TABLE `compras_prov`
  ADD CONSTRAINT `compras_prov_ibfk_1` FOREIGN KEY (`ID_Proveedor`) REFERENCES `proveedores` (`ID_Proveedor`);

--
-- Filtros para la tabla `detalle_factura`
--
ALTER TABLE `detalle_factura`
  ADD CONSTRAINT `detalle_factura_ibfk_1` FOREIGN KEY (`ID_Factura`) REFERENCES `facturas` (`ID_Factura`),
  ADD CONSTRAINT `detalle_factura_ibfk_2` FOREIGN KEY (`ID_Producto`) REFERENCES `productos` (`ID_Producto`);

--
-- Filtros para la tabla `devoluciones`
--
ALTER TABLE `devoluciones`
  ADD CONSTRAINT `devoluciones_ibfk_1` FOREIGN KEY (`ID_Factura`) REFERENCES `facturas` (`ID_Factura`),
  ADD CONSTRAINT `devoluciones_ibfk_2` FOREIGN KEY (`ID_Producto`) REFERENCES `productos` (`ID_Producto`);

--
-- Filtros para la tabla `facturas`
--
ALTER TABLE `facturas`
  ADD CONSTRAINT `facturas_ibfk_1` FOREIGN KEY (`ID_Cliente`) REFERENCES `clientes` (`ID_Cliente`);

--
-- Filtros para la tabla `inventario`
--
ALTER TABLE `inventario`
  ADD CONSTRAINT `inventario_ibfk_1` FOREIGN KEY (`ID_Producto`) REFERENCES `productos` (`ID_Producto`);

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`ID_Categoria`) REFERENCES `categoria_productos` (`ID_Categoria`);

--
-- Filtros para la tabla `puntos`
--
ALTER TABLE `puntos`
  ADD CONSTRAINT `puntos_ibfk_1` FOREIGN KEY (`ID_Cliente`) REFERENCES `clientes` (`ID_Cliente`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

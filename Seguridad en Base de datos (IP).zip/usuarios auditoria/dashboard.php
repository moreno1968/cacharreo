<?php
session_start();
require 'conexion.php';

if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role'])) {
    echo "<script>alert('Debes iniciar sesión primero.'); window.location.href='index.php';</script>";
    exit();
}


$usuario_id = $_SESSION['user_id'];
$rol = $_SESSION['user_role'];

$nombre_usuario = 'Desconocido';
$ip = 'No detectada';

$stmt = $conn->prepare("SELECT nombre FROM usuarios WHERE id = ?");
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$stmt->bind_result($nombre_usuario);
$stmt->fetch();
$stmt->close();


function obtenerIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) return $_SERVER['HTTP_CLIENT_IP'];
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) return $_SERVER['HTTP_X_FORWARDED_FOR'];
    return $_SERVER['REMOTE_ADDR'];
}
$ip = obtenerIP();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            padding: 30px;
            text-align: center;
        }
        .container {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            display: inline-block;
        }
        input, button {
            padding: 10px;
            margin: 8px 0;
            width: 250px;
        }
        button {
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Bienvenido, <?php echo htmlspecialchars($nombre_usuario); ?> 👋</h1>
        <p>Rol: <strong><?php echo htmlspecialchars($rol); ?></strong></p>
        <p>Tu IP: <?php echo $ip; ?></p>

        <hr>

        <h2>Modificar Stock</h2>
        <form action="modificar_stock.php" method="POST">
            <input type="number" name="id_producto" placeholder="ID del Producto" required><br>
            <input type="number" name="nuevo_stock" placeholder="Nuevo Stock" required><br>
            <button type="submit">Actualizar Stock</button>
        </form>

        <br>
        <form action="logout.php" method="POST">
            <button type="submit" name="logout">Cerrar Sesión</button>
        </form>
    </div>
</body>
</html>

<?php
session_start();
require 'conexion.php';


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['registro'])) {
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $rol = $_POST['rol'];

   
    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo "<script>alert('El correo ya está registrado.');</script>";
    } else {
       
        $stmt = $conn->prepare("INSERT INTO usuarios (nombre, email, password_hash, rol, intentos_fallidos, bloqueado) VALUES (?, ?, ?, ?, 0, 0)");
        $stmt->bind_param("ssss", $nombre, $email, $password, $rol);

        if ($stmt->execute()) {
            echo "<script>alert('Registro exitoso. Ahora puedes iniciar sesión.'); window.location.href='index.php';</script>";
        } else {
            echo "<script>alert('Error en el registro. Intenta de nuevo.');</script>";
        }
    }
    $stmt->close();
}


if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, password_hash, rol, intentos_fallidos, bloqueado FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $password_hash, $rol, $intentos_fallidos, $bloqueado);
        $stmt->fetch();
        
        if ($bloqueado) {
            echo "<script>alert('Cuenta bloqueada. Contacte al administrador.');</script>";
        } elseif (password_verify($password, $password_hash)) { 
            $stmt = $conn->prepare("UPDATE usuarios SET intentos_fallidos = 0 WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            
            $_SESSION['user_id'] = $id;
            $_SESSION['user_role'] = $rol;
            echo "<script>alert('Inicio de sesión exitoso'); window.location.href='dashboard.php';</script>";
        } else {
            $intentos_fallidos++;
            $stmt = $conn->prepare("UPDATE usuarios SET intentos_fallidos = ? WHERE id = ?");
            $stmt->bind_param("ii", $intentos_fallidos, $id);
            $stmt->execute();
            
            if ($intentos_fallidos >= 4) {
                $stmt = $conn->prepare("UPDATE usuarios SET bloqueado = TRUE WHERE id = ?");
                $stmt->bind_param("i", $id);
                $stmt->execute();
                echo "<script>alert('Cuenta bloqueada por intentos fallidos.');</script>";
            } else {
                echo "<script>alert('Contraseña incorrecta. Intentos restantes: " . (4 - $intentos_fallidos) . "');</script>";
            }
        }
    } else {
        echo "<script>alert('Usuario no encontrado.');</script>";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro e Inicio de Sesión</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="registro-container">
        <h2>Registro de Usuario</h2>
        <form action="" method="POST">
            <input type="text" name="nombre" placeholder="Nombre Completo" required>
            <input type="email" name="email" placeholder="Correo Electrónico" required>
            <input type="password" name="password" placeholder="Contraseña" required>
            <select name="rol" required>
                <option value="Cliente">Cliente</option>
                <option value="Vendedor">Vendedor</option>
                <option value="Administrador">Administrador</option>
            </select>
            <button type="submit" name="registro">Registrarse</button>
        </form>
    </div>
    
    <div class="login-container">
        <h2>Iniciar Sesión</h2>
        <form action="" method="POST">
            <input type="email" name="email" placeholder="Correo Electrónico" required>
            <input type="password" name="password" placeholder="Contraseña" required>
            <button type="submit" name="login">Ingresar</button>
        </form>
    </div>
</body>
</html>

<style>
body {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100vh;
    background: url('images.jpg') no-repeat center center fixed;
    background-size: cover;
    font-family: Arial, sans-serif;
}

.registro-container, .login-container {
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    text-align: center;
    width: 300px;
    margin-bottom: 20px;
}

input, select {
    width: 100%;
    padding: 10px;
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 5px;
}

button {
    width: 100%;
    padding: 10px;
    background: #007BFF;
    border: none;
    color: white;
    border-radius: 5px;
    cursor: pointer;
}

button:hover {
    background: #0056b3;
}
</style>

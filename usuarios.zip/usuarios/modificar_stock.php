<?php
session_start();
require 'conexion.php';


if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('Debes iniciar sesión.'); window.location.href='control.php';</script>";
    exit();
}


function obtenerIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) return $_SERVER['HTTP_CLIENT_IP'];
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) return $_SERVER['HTTP_X_FORWARDED_FOR'];
    return $_SERVER['REMOTE_ADDR'];
}

$ip = obtenerIP();
$usuario_id = $_SESSION['user_id'];


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_producto = $_POST['id_producto'];
    $nuevo_stock = $_POST['nuevo_stock'];

   
    $sql = "UPDATE productos 
            SET stock = ?, direccion_ip = ?, usuario_id = ? 
            WHERE id_producto = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssii", $nuevo_stock, $ip, $usuario_id, $id_producto);

    if ($stmt->execute()) {
        echo "<script>alert('Stock actualizado y auditoría registrada.'); window.location.href='dashboard.php';</script>";
    } else {
        echo "<script>alert('Error al actualizar stock.');</script>";
    }

    $stmt->close();
}
?>
